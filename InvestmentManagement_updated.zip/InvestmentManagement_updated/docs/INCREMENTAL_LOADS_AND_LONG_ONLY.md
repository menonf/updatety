# Incremental loads, long-only books and the modular factor library

What was added in this round, how it fits together, how to operate it, and what to do next.

## 1. What changed, at a glance

| Ask | Where it lives | Notebook |
|---|---|---|
| Append reference data and prices daily / monthly, detect index rebalances | `data_engineering/loaders/incremental.py` (`check_index_membership`, `apply_membership_diff`, `extend_*_holdings`, `refresh_float_shares`, `refresh_prices`, `price_gaps`) | **01A** |
| Load new fundamentals as they are published | `incremental.py` (`load_fundamentals_incremental`, `diff_fundamentals`), `analytics.factors.ml_training.retrain_recommended` | **03A** |
| Long-only portfolio | `analytics/portfolio/sizing.py`, `analytics/portfolio/long_only.py`, `analytics/strategy.py` | **04A** |
| Weights on the screen | `analytics/screening.py` (`build_screen(position_weighting=..., long_only=...)`, `size_positions`, `trade_list`) | **05** (patched), **05A** |
| Modular factors: add a ratio, add a growth factor | `analytics/factors/library.py` (`RatioSpec`, `RatioCompositeFactor`, `GrowthFactor`, `QualityFactor`), `data_engineering/fundamentals/ratios.py` (`GROWTH_COLUMNS`, `compute_growth_ratios`) | 04A / 05A |
| One strategy definition for backtest *and* screen | `analytics/strategy.py` (`StrategyConfig`, `SignalSpec`) | 04A / 05A |
| Automation | `toolkit/scripts/incremental_load.py` | - |

Four new test modules (`test_factor_library`, `test_sizing_long_only`, `test_screening_weights`,
`test_incremental`) cover the pure logic without a database or vendor; the existing suite is unchanged and passing.

## 2. Incremental loads (01A / 03A / `incremental_load.py`)

### Design

* **The window is derived from the data, not the calendar.** `resolve_price_window` starts `BUFFER_DAYS` business
  days before the latest `market_data` date and ends at `AS_OF`. Running daily gives a 4-day window, running after a
  month gives a 5-week window - same code. Every write is an upsert (`market_data` delete-then-insert per
  security/date, `security_fundamentals` MERGE, holdings replaced per date), so overlap is free and repairs late
  vendor corrections.
* **Index constitution** is checked by *diffing state*, not by replaying events: today's LSEG constituent list is
  resolved to `security_id` (exact RIC → normalised RIC → event-suffix stripped; nothing is created during a check)
  and compared with the open intervals (`end_date IS NULL`) in `reference.index_constituents`. LSEG's joiner /
  leaver events over the last 45 days supply the exact change dates; when an event is missing the snapshot date
  is used. Applying the diff closes intervals with a SQL `UPDATE` and inserts new ones - the history is never
  rewritten. Futures tickers that leak into the `.SPX` chain (`ES`, `NQ`, ...) are dropped as in the full load.
* **Holdings** are appended only for the dates in the window (`upsert_holdings_window` deletes exactly those dates
  for the portfolio first). SP500 rows come from the updated intervals; SPY / GSPC / MAG8 are constant books.
* **Prices** are pulled only for members whose interval overlaps the window (`build_backtest_universe(start_date=,
  end_date=)`), so delisted leavers are not re-requested every day. Names with fewer than half the window's business
  days are re-pulled one at a time; holdings on dates where fewer than half the names have a price (holidays) are
  pruned; `price_gaps` reports the remaining holes against a trading calendar *inferred from the data* (a date counts
  when ≥ 50 % of the universe is priced), so holidays are never reported as gaps.
* **Fundamentals** are pulled for the last two fiscal quarters and classified cell by cell against the stored rows:
  *new period* (a new quarter published), *new cell* (a metric added to a known period - e.g. growth back-fill),
  *restatement* (value differs beyond 1e-6 relative), *unchanged*. Only new and restated cells are written. The
  diff tells you which securities published, which returned nothing (late filers), and whether the ML models are
  now stale (`retrain_recommended`: a period newer than the models' training cut-off has become *available*, i.e.
  period end + publication lag ≤ today).

### Operating checklist

1. Run **01** and **03** once (history). Enable growth in 03 by building the Refinitiv provider with
   `include_growth=True` (default) - the first full load stores `GROWTH_COLUMNS` too.
2. Schedule `python toolkit/scripts/incremental_load.py --fundamentals` after the US close (EOD prices must be
   published; if the job runs too early, that day's holdings are pruned and simply re-created by the next run).
   Exit code 2 = some names still missing (see log), 1 = error.
3. Review `toolkit/files/reference/membership_changes_*.csv` when the log shows joiners / leavers - an unresolved
   joiner means a brand-new listing was created in `security_master`; check its identifiers.
4. When 03A (or the script) says **RETRAIN RECOMMENDED**, re-run the training cell in 05 / 05A with
   `RETRAIN = True` (walk-forward refits are a better long-term answer, see §5).
5. Monthly, glance at `price_gaps` and `check_fundamentals_coverage.py`.

### Things to know

* `portfolio_holdings.as_of_date` and `index_constituents.start_date / end_date` are **strings** in the ORM; the
  incremental code formats dates as `YYYY-MM-DD` to match. If the physical columns are `DATE`, SQL Server converts
  implicitly.
* `apply_membership_diff(create_missing=False)` skips unknown joiners instead of creating master rows - useful if
  you prefer to onboard new listings by hand.
* The first ~8 quarters after enabling growth show partial growth coverage for securities whose history starts at
  `FROM_DATE`; the provider pulls 8 extra quarters of raw items behind `start_date` so this only affects names
  that genuinely lack history.

## 3. The factor library

* A fundamentals factor is a list of `RatioSpec(column, direction, transform, positive_only, weight, winsor)`.
  `RatioCompositeFactor` orients each component so that higher = better, winsorises, z-scores across the
  cross-section and takes the weighted mean of the available components (`min_components` guards sparse names).
* `ValueFactor`, `QualityFactor`, `GrowthFactor` are presets (`VALUE_SPECS`, `QUALITY_SPECS`, `GROWTH_SPECS`) with
  `extra=` / `drop=` arguments. `ValueFactor()` is numerically identical to the previous implementation.
* **Growth** uses the new `GROWTH_COLUMNS`: TTM revenue / earnings / EBIT growth (trailing-four-quarter sums versus
  the sums a year earlier, defined only when both are positive), gross-margin change, asset growth and share
  issuance. They are computed per security from the quarterly raw items on the security's own fiscal grid, so a
  missing quarter yields NaN rather than a misaligned comparison. Asset growth and share issuance are *negative*
  predictors and sit in the quality preset with `direction=-1`.
* **Contract separation.** `RATIO_COLUMNS` (18) stays the ML feature contract; `METRIC_COLUMNS` = ratios + growth
  is the storage contract. Providers serve the 18 by default and the full set with `metric_columns=METRIC_COLUMNS`;
  `compute_signals` raises a clear error when a growth factor meets a provider that does not serve growth.

## 4. Long-only construction and sizing

`analytics/portfolio/sizing.py`

* `position_weights(signal, quantile, long_only, scheme, ...)` keeps `quantile_weights`' selection and sizes the
  legs: `equal`, `score` (∝ composite z-score in the leg's direction, floored so every selected name is held),
  `rank`, `inverse_vol` (∝ 1 / trailing volatility, `trailing_volatility(prices, 63)`), `market_cap`.
* `buffered_weights(signal, quantile, exit_quantile, dates=...)` is the holding buffer from
  `STRATEGY_IMPROVEMENTS.md` B.4: a name is kept while it stays inside the wider band; on synthetic data it halves
  turnover. `exit_quantile == quantile` reproduces the plain book exactly (unit-tested).
* `cap_weights` now logs when a cap is infeasible (16 names cannot carry 100 % at a 5 % cap) instead of silently
  leaving the leg under-invested.

`analytics/portfolio/long_only.py`

* `tilt_weights(benchmark, signal, strength, max_active)` - enhanced index: `w ∝ b · exp(strength · z)`, names
  without a score held at benchmark weight, `|w − b| ≤ max_active` enforced by a water-filling projection
  (`clip_active_weights`).
* `cap_sector_weights(weights, sector_map, max_sector_weight, max_weight=None)` - sector caps, jointly with the
  per-name cap when given; warns when the two are infeasible together.
* `active_weights`, `sector_weights`, `membership_matrix` (vectorised replacement for the per-date loop in 04).

`analytics/backtest/metrics.py` - `summary_table(benchmark=...)` now also reports `active_return` and
`information_ratio`, which is how a long-only book should be judged.

## 5. Improvements you may have missed (prioritised)

**Correctness of what you already run**

1. **The screen was not trading the backtested book.** Notebook 04 blends momentum / ML value 50:50; notebook 05
   used 30:70. `StrategyConfig` removes the possibility (04A and 05A read the same object; 05 now carries a note).
   Decide which blend you want and put it in one place.
2. **Publication dates.** `availability_lag_days = 45` is a blunt proxy; large caps file 10-Qs in ~30 days, 10-Ks in
   ~55-60, and some names are habitually late. Store LSEG's announcement date per period
   (`TR.BSOriginalAnnouncementDate` / `TR.ISPeriodEndDate`) as an `available_date` column and let the provider use
   it; the incremental loader is the natural place to back-fill it.
3. **Total return.** Confirm `TR.CLOSEPRICE(Adjusted=1)` includes dividends in your entitlement; if it is
   split-adjusted only, a long-only book that tilts into high-yield value names is under-stated and the short leg
   in 04 is flattered. The `dividends` column is written as 0 today.
4. **The 25 % implausible-move filter** drops genuine prints (earnings gaps above 25 % happen a few times a year in
   the S&P 500). Flag instead of drop, and confirm against the `close` / `adj_close` ratio or a second vendor.
5. **Survivorship in training.** `build_modelling_table` trains on every security in `security_master`, not on
   point-in-time members; fine for sample size, but evaluate the model on members only (04A §4A.6 does).

**Signal and model**

6. **Walk-forward retraining.** The persisted models were trained once (metadata `as_of = 2026-08-31`). Refit
   yearly on an expanding window and score the next year with that year's models; `retrain_recommended` is the
   trigger, `train_models(model_dir=f".../sp500_{year}")` the mechanism.
7. **Use the growth metrics in the ML model** by adding `feature_columns` to `time_based_split` / `train_models`
   (today they select `RATIO_COLUMNS` by name) and retraining; compare rank IC before adopting.
8. **IC-weighted blending** (D.2): weight each `SignalSpec` by its trailing 24-month IC, floored at zero, so a
   signal that stopped working is de-emphasised automatically. Fits naturally as `StrategyConfig(blend_method="ic")`.
9. **Sector-neutral scores** (`neutralize(composite, sector_map)`) before `build_weights` - 04A shows the long-only
   book's sector bets; neutralising at the signal level is cleaner than capping at the weight level.
10. **Residual momentum / volatility scaling** are built in (`MomentumFactor(vol_scale=True)`); run them through
    the IC table side by side with the plain 12-1.

**Portfolio**

11. **Risk targeting** - scale the active book to a constant ex-ante tracking error (or the L/S book to 10 %
    volatility) using trailing 63-day realised numbers; makes Sharpe / IR comparable across regimes.
12. **Beta-aware active weights** for long-only (momentum longs run high beta); report beta in 04A and consider a
    beta-neutral tilt.
13. **Transaction-cost realism** - size-dependent costs (bps rising with weight / ADV) and a borrow fee for the
    short leg; the equal 10 bps flatters concentrated books.
14. **Liquidity screen** - minimum market cap / ADV from `shares_outstanding × price` before ranking
    (`position_weights(scale=...)` already carries market cap; add a mask).

**Data engineering / operations**

15. **Store announcement dates** (see 2) and **persist daily factor scores** (`WRITE_FACTOR_SCORES = True`) so the
    signal history is auditable and the screen's `screen_changes` can be reconstructed from the database.
16. **Vendor fail-over for prices** - `refresh_prices(vendor="yahoo")` for the handful of names LSEG keeps
    missing, written with their own `source_vendor`, and a reconciliation report between vendors.
17. **Idempotency guard for `portfolio`** - `get_or_create_portfolio` matches on `(short_name, type)`;
    `get_portfolio_market_data` already defends against duplicate rows, but a unique index on
    `portfolio_short_name` would stop them at the source.
18. **A scheduler-friendly health check** - the CLI's exit codes are a start; add a small JSON run log
    (window, counts, missing names, retrain flag) per run under `toolkit/files/reference/` for trend monitoring.
19. **Pin the strategy with the export** - 05A writes `strategy_lo_<universe>_<date>.json` next to the screen;
    do the same in 05 so every historical screen carries the definition that produced it.
20. **Run `pre-commit run --all-files`** after pulling these changes - the new modules follow the repo's
    black / flake8 / pydocstyle conventions, but the formatter was not available where they were written.
