"""Configuration package for InvestmentManagement."""
