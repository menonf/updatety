"""Point-in-time universe membership as a boolean date x security_id matrix."""

from __future__ import annotations

from typing import Iterable, Optional

import pandas as pd
from pandas import DataFrame, Series


def membership_matrix(members_on: Optional[Series], dates: Iterable, columns: Iterable) -> DataFrame:
    """Expand a ``snapshot_date -> set(security_id)`` Series into a boolean date x security frame.

    On each date in ``dates`` the latest snapshot on or before it applies (the
    holdings table only has rows on business days, so a weekend / holiday date
    inherits the previous snapshot). Dates before the first snapshot are all
    ``False``. ``members_on`` is the shape returned by
    :func:`data_engineering.loaders.portfolios.portfolio_members_on`; with
    ``None`` every security is a member on every date.

    Vectorised replacement for the per-date ``.loc`` loop in notebook 04.
    """
    idx = pd.DatetimeIndex(pd.to_datetime(list(dates)))
    cols = pd.Index(list(columns))
    if members_on is None or len(members_on) == 0:
        return DataFrame(True, index=idx, columns=cols)
    snaps = members_on.copy()
    snaps.index = pd.DatetimeIndex(pd.to_datetime(snaps.index))
    snaps = snaps.sort_index()
    long = DataFrame(
        [(dt, int(sec)) for dt, members in snaps.items() for sec in members],
        columns=["snapshot_date", "security_id"],
    )
    if long.empty:
        return DataFrame(False, index=idx, columns=cols)
    long["flag"] = True
    snapshot_matrix = long.pivot_table(index="snapshot_date", columns="security_id", values="flag", aggfunc="any", fill_value=False)
    # a snapshot applies from its date until the next snapshot: reindex onto the union and forward-fill
    union = snapshot_matrix.index.union(idx)
    filled = snapshot_matrix.reindex(union).ffill().reindex(idx)
    filled = filled.reindex(columns=cols)
    return filled.fillna(False).astype(bool)


__all__ = ["membership_matrix"]
