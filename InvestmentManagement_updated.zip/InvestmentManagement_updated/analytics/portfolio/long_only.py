"""Long-only portfolio construction on top of a cross-sectional signal.

Three ways to hold a long-only factor book, from most to least concentrated:

    long_only_weights(signal, quantile=0.2, scheme="equal")        # top quintile, equal weight
    long_only_weights(signal, quantile=0.2, scheme="score")        # top quintile, conviction weighted
    tilt_weights(benchmark_weights, signal, strength=1.0)          # the whole benchmark, tilted
                                                                   # towards high scores ("enhanced index")

plus constraints that matter for a real long-only mandate:

    cap_sector_weights(weights, sector_map, max_sector_weight=0.30)
    active_weights(weights, benchmark_weights)                     # what you are actually betting on

All functions return date x security_id weight frames that sum to 1 on every
invested date (zeros before the signal exists), ready for ``run_backtest``.
"""

from __future__ import annotations

import logging
from typing import Optional

import numpy as np
import pandas as pd
from pandas import DataFrame, Series

from .long_short import cap_weights
from .sizing import position_weights

log = logging.getLogger(__name__)


def long_only_weights(
    signal: DataFrame,
    quantile: float = 0.2,
    scheme: str = "equal",
    membership: Optional[DataFrame] = None,
    min_names: int = 4,
    max_weight: Optional[float] = None,
    scale: Optional[DataFrame] = None,
) -> DataFrame:
    """Top-``quantile`` long book sized with ``scheme`` (see :func:`~analytics.portfolio.sizing.position_weights`)."""
    return position_weights(
        signal, quantile, long_only=True, scheme=scheme, membership=membership, min_names=min_names, max_weight=max_weight, scale=scale
    )


def tilt_weights(
    benchmark_weights: DataFrame,
    signal: DataFrame,
    strength: float = 1.0,
    membership: Optional[DataFrame] = None,
    max_weight: Optional[float] = None,
    max_active: Optional[float] = None,
    clip_z: float = 3.0,
) -> DataFrame:
    """Multiplicative tilt of benchmark weights towards high signal scores.

    ``w_i = b_i * exp(strength * z_i) / sum_j b_j * exp(strength * z_j)`` where
    ``z`` is the cross-sectional z-score of ``signal`` over the benchmark's
    members on each date (clipped to ``+/- clip_z``). A name without a score
    gets ``z = 0`` (held at its benchmark weight), so missing fundamentals
    never force a sale. ``strength = 0`` returns the benchmark itself; around
    ``1`` gives a typical enhanced-index tracking error of a few percent.

    Args:
        benchmark_weights: date x security_id benchmark weights (rows sum to 1).
        signal: date x security_id scores (higher = better).
        strength: tilt aggressiveness.
        membership: optional eligibility mask applied to the signal (names
            outside it are held at benchmark weight, not sold).
        max_weight: optional absolute cap per name.
        max_active: optional cap on ``|w_i - b_i|`` per name (the tilt is
            clipped and the book renormalised).
        clip_z: z-score clip to keep a single outlier from dominating.
    """
    b = benchmark_weights.reindex(index=signal.index.union(benchmark_weights.index)).sort_index()
    b = b.reindex(columns=signal.columns.union(b.columns)).fillna(0.0)
    s = signal.reindex(index=b.index, columns=b.columns).astype(float)
    if membership is not None:
        s = s.where(membership.reindex(index=b.index, columns=b.columns).fillna(False).astype(bool))
    in_bench = b > 0
    s = s.where(in_bench)
    z = s.sub(s.mean(axis=1), axis=0).div(s.std(axis=1, ddof=0).replace(0, np.nan), axis=0)
    z = z.clip(lower=-clip_z, upper=clip_z).fillna(0.0)
    tilted = b * np.exp(strength * z)
    weights = tilted.div(tilted.sum(axis=1).replace(0, np.nan), axis=0).fillna(0.0)
    if max_active is not None:
        weights = clip_active_weights(weights, b, max_active)
    if max_weight is not None:
        weights = cap_weights(weights, max_weight)
    return weights.reindex(index=signal.index).fillna(0.0)


def clip_active_weights(weights: DataFrame, benchmark_weights: DataFrame, max_active: float, max_iter: int = 100) -> DataFrame:
    """Project ``weights`` onto ``|w - b| <= max_active`` while keeping each row's total and ``w >= 0``.

    Water-filling: clip every active weight to the band, then spread the
    resulting row shortfall / excess pro-rata over the names that still have
    room inside the band, and repeat until no name breaches the band. Rows
    where the band cannot absorb the total (every name pinned) keep the
    clipped weights and are renormalised as a last resort.
    """
    if max_active <= 0:
        raise ValueError("max_active must be > 0")
    b = benchmark_weights.reindex(index=weights.index, columns=weights.columns).fillna(0.0)
    lo = (b - max_active).clip(lower=0.0)
    hi = b + max_active
    target = weights.sum(axis=1)
    w = weights.copy()
    for _ in range(max_iter):
        w = w.clip(lower=lo, upper=hi)
        residual = target - w.sum(axis=1)
        if (residual.abs() < 1e-12).all():
            break
        room = (hi - w).where(residual.gt(0), (w - lo), axis=0)  # room in the direction we must move
        room = room.clip(lower=0.0)
        room_sum = room.sum(axis=1).replace(0, np.nan)
        w = w + room.div(room_sum, axis=0).mul(residual, axis=0).fillna(0.0)
    w = w.clip(lower=lo, upper=hi)
    stuck = (target - w.sum(axis=1)).abs() > 1e-9
    if stuck.any():
        w.loc[stuck] = w.loc[stuck].div(w.loc[stuck].sum(axis=1).replace(0, np.nan), axis=0).mul(target[stuck], axis=0).fillna(0.0)
    return w


def active_weights(weights: DataFrame, benchmark_weights: DataFrame) -> DataFrame:
    """``weights - benchmark`` on the union of names (positive = overweight)."""
    cols = weights.columns.union(benchmark_weights.columns)
    w = weights.reindex(columns=cols).fillna(0.0)
    b = benchmark_weights.reindex(index=w.index, columns=cols).fillna(0.0)
    return w - b


def cap_sector_weights(
    weights: DataFrame, sector_map: Series, max_sector_weight: float, max_weight: Optional[float] = None, max_iter: int = 50
) -> DataFrame:
    """Cap each sector's total weight (long-only), redistributing the excess pro-rata to the other sectors.

    Iterative water-filling on sector totals; within a capped sector, names keep
    their relative proportions. Names without a sector form their own group
    (label ``"Unknown"``). Rows keep their original gross exposure. With
    ``max_weight`` the per-name cap is enforced *jointly* (the redistribution
    into other sectors can otherwise push a name over its cap): the two
    projections alternate until both constraints hold.
    """
    if not 0 < max_sector_weight <= 1:
        raise ValueError("max_sector_weight must be in (0, 1]")
    groups = sector_map.reindex(weights.columns).fillna("Unknown")
    out = weights.clip(lower=0.0).fillna(0.0)
    target = out.sum(axis=1)
    for _ in range(max_iter):
        sector_tot = out.T.groupby(groups).sum().T  # date x sector
        over = sector_tot > max_sector_weight + 1e-12
        name_over = max_weight is not None and bool((out > max_weight + 1e-12).to_numpy().any())
        if not over.to_numpy().any() and not name_over:
            break
        if over.to_numpy().any():
            scale = (max_sector_weight / sector_tot).where(over, 1.0).clip(upper=1.0)
            out = out * scale.reindex(columns=groups.to_numpy(), fill_value=1.0).set_axis(out.columns, axis=1)
            shortfall = target - out.sum(axis=1)
            free_sectors = ~over
            free_cols = out.where(free_sectors.reindex(columns=groups.to_numpy()).set_axis(out.columns, axis=1), 0.0)
            free_sum = free_cols.sum(axis=1).replace(0, np.nan)
            out = out + free_cols.div(free_sum, axis=0).mul(shortfall, axis=0).fillna(0.0)
        if max_weight is not None:
            out = cap_weights(out, max_weight)
    final = out.T.groupby(groups).sum().T
    breach = final > max_sector_weight + 1e-6
    if breach.to_numpy().any():
        worst = float(final.max().max())
        log.warning(
            "cap_sector_weights: sector cap %.2f cannot be met jointly with the other constraints on %d date(s) "
            "(worst sector weight %.3f); too few names outside the capped sectors to absorb the weight - "
            "widen the quantile or relax max_weight.",
            max_sector_weight,
            int(breach.any(axis=1).sum()),
            worst,
        )
    return out


def sector_weights(weights: DataFrame, sector_map: Series) -> DataFrame:
    """Total weight per sector per date (date x sector)."""
    groups = sector_map.reindex(weights.columns).fillna("Unknown")
    return weights.fillna(0.0).T.groupby(groups).sum().T


__all__ = ["long_only_weights", "tilt_weights", "active_weights", "clip_active_weights", "cap_sector_weights", "sector_weights"]
