"""Position sizing: turn a *selection* into *weights* (equal, score, rank, inverse-vol, market-cap).

:func:`analytics.portfolio.long_short.quantile_weights` decides *which* names
are in each leg and equal-weights them. This module keeps that selection and
changes *how much* each name gets:

    position_weights(signal, 0.1, scheme="score")                      # conviction-weighted L/S
    position_weights(signal, 0.2, long_only=True, scheme="inverse_vol",
                     scale=trailing_volatility(prices, 63))             # risk-parity-ish long book
    buffered_weights(signal, 0.1, exit_quantile=0.15, dates=rebalances) # hold until a name leaves the top 15 %

Every function returns a date x security_id frame whose long leg sums to +1
and (unless ``long_only``) whose short leg sums to -1, exactly like
``quantile_weights``, so the result plugs straight into ``run_backtest``.
"""

from __future__ import annotations

import math
from typing import Optional

import numpy as np
import pandas as pd
from pandas import DataFrame, Series

from .long_short import cap_weights, quantile_weights

SCHEMES = ("equal", "score", "rank", "inverse_vol", "market_cap")


def trailing_volatility(prices: DataFrame, window: int = 63, min_periods: Optional[int] = None) -> DataFrame:
    """Annualised trailing volatility of daily returns (date x security_id) for ``inverse_vol`` sizing."""
    daily = prices.sort_index().pct_change(fill_method=None)
    return daily.rolling(window, min_periods=min_periods or max(5, window // 2)).std() * math.sqrt(252)


def _leg_raw(signal: DataFrame, mask: DataFrame, scheme: str, scale: Optional[DataFrame], sign: float) -> DataFrame:
    """Positive sizing inputs for the names in ``mask`` (zero elsewhere)."""
    if scheme == "equal":
        return mask.astype(float)
    if scheme == "rank":
        # 1 .. n within the leg: the best long (or worst short) gets the largest weight
        ranked = (signal * sign).where(mask).rank(axis=1, ascending=True, method="first")
        return ranked.fillna(0.0)
    if scheme == "score":
        # distance of the cross-sectional z-score from zero, in the leg's direction; a floor keeps
        # every selected name invested even when its z-score sits at (or just across) zero
        z = signal.sub(signal.mean(axis=1), axis=0).div(signal.std(axis=1, ddof=0).replace(0, np.nan) + 1e-9, axis=0)
        raw = (z * sign).where(mask)
        floor = raw.abs().mean(axis=1).fillna(0.0) * 0.10
        raw = raw.clip(lower=0.0).add(floor, axis=0)
        return raw.where(mask, 0.0).fillna(0.0)
    if scheme in ("inverse_vol", "market_cap"):
        if scale is None:
            raise ValueError(f"scheme='{scheme}' needs a `scale` frame (date x security_id)")
        s = scale.reindex(index=signal.index, columns=signal.columns).astype(float)
        raw = (1.0 / s.where(s > 0)) if scheme == "inverse_vol" else s.where(s > 0)
        raw = raw.where(mask)
        # a selected name without a scale value gets the leg's median so it is not silently dropped
        med = raw.median(axis=1)
        raw = raw.T.fillna(med).T
        return raw.where(mask, 0.0).fillna(0.0)
    raise ValueError(f"unknown scheme '{scheme}'. Available: {SCHEMES}")


def reweight_selection(
    signal: DataFrame,
    long_mask: DataFrame,
    short_mask: Optional[DataFrame],
    scheme: str = "equal",
    scale: Optional[DataFrame] = None,
    max_weight: Optional[float] = None,
) -> DataFrame:
    """Size a given long / short selection with ``scheme`` (long leg -> +1, short leg -> -1)."""
    long_raw = _leg_raw(signal, long_mask, scheme, scale, +1.0)
    weights = long_raw.div(long_raw.sum(axis=1).replace(0, np.nan), axis=0).fillna(0.0)
    if short_mask is not None and short_mask.to_numpy().any():
        short_raw = _leg_raw(signal, short_mask, scheme, scale, -1.0)
        weights = weights - short_raw.div(short_raw.sum(axis=1).replace(0, np.nan), axis=0).fillna(0.0)
    if max_weight is not None:
        weights = cap_weights(weights, max_weight)
    return weights


def position_weights(
    signal: DataFrame,
    quantile: float = 0.1,
    long_only: bool = False,
    scheme: str = "equal",
    membership: Optional[DataFrame] = None,
    min_names: int = 4,
    max_weight: Optional[float] = None,
    scale: Optional[DataFrame] = None,
) -> DataFrame:
    """Select the top (and bottom) ``quantile`` of ``signal`` and size the legs with ``scheme``.

    Args:
        signal: date x security_id scores (higher = better; NaN = ineligible).
        quantile: fraction of eligible names per leg.
        long_only: build only the long leg (weights sum to +1).
        scheme: ``"equal"`` | ``"score"`` (proportional to the cross-sectional
            z-score in the leg's direction) | ``"rank"`` (linear in rank within
            the leg) | ``"inverse_vol"`` (proportional to ``1 / scale``) |
            ``"market_cap"`` (proportional to ``scale``).
        membership: optional boolean date x security_id eligibility mask.
        min_names: dates with fewer eligible names get zero weights.
        max_weight: optional per-name cap (excess redistributed within the leg).
        scale: date x security_id inputs for ``inverse_vol`` / ``market_cap``
            (see :func:`trailing_volatility`).
    """
    if scheme not in SCHEMES:
        raise ValueError(f"unknown scheme '{scheme}'. Available: {SCHEMES}")
    base = quantile_weights(signal, quantile, long_only=long_only, membership=membership, min_names=min_names)
    if scheme == "equal":
        return cap_weights(base, max_weight) if max_weight is not None else base
    sig = signal.astype(float)
    if membership is not None:
        sig = sig.where(membership.reindex(index=sig.index, columns=sig.columns).fillna(False).astype(bool))
    return reweight_selection(sig, base > 0, None if long_only else base < 0, scheme, scale, max_weight)


def buffered_weights(
    signal: DataFrame,
    quantile: float = 0.1,
    exit_quantile: float = 0.15,
    long_only: bool = False,
    dates: Optional[pd.DatetimeIndex] = None,
    membership: Optional[DataFrame] = None,
    min_names: int = 4,
    scheme: str = "equal",
    scale: Optional[DataFrame] = None,
    max_weight: Optional[float] = None,
) -> DataFrame:
    """Quantile book with a holding buffer (hysteresis) to cut turnover.

    On each rebalance date a name already held stays in the leg as long as it
    still ranks inside the wider ``exit_quantile`` band; new names are only
    added, best first, to fill the leg back up to ``ceil(quantile x eligible)``.
    Between rebalance dates the previous book is carried forward. With
    ``exit_quantile == quantile`` this reproduces :func:`position_weights`.

    Args:
        signal: date x security_id scores (NaN = ineligible).
        quantile: target leg size as a fraction of eligible names.
        exit_quantile: band a held name may fall to before it is sold (>= ``quantile``).
        long_only: only build the long leg.
        dates: rebalance dates (default: every date in ``signal``).
        membership / min_names / scheme / scale / max_weight: as in :func:`position_weights`.
    """
    if not 0 < quantile <= exit_quantile <= 0.5:
        raise ValueError("need 0 < quantile <= exit_quantile <= 0.5")
    sig = signal.astype(float)
    if membership is not None:
        sig = sig.where(membership.reindex(index=sig.index, columns=sig.columns).fillna(False).astype(bool))
    rebalance = pd.DatetimeIndex(sig.index) if dates is None else pd.DatetimeIndex(dates).intersection(pd.DatetimeIndex(sig.index))

    long_mask = DataFrame(False, index=sig.index, columns=sig.columns)
    short_mask = DataFrame(False, index=sig.index, columns=sig.columns)
    held_long: set = set()
    held_short: set = set()
    rebalance_set = set(rebalance)
    for dt in sig.index:
        if dt in rebalance_set:
            row = sig.loc[dt].dropna()
            n = len(row)
            if n < min_names:
                held_long, held_short = set(), set()
            else:
                n_target = max(1, math.ceil(quantile * n))
                n_exit = max(n_target, math.ceil(exit_quantile * n))
                desc = row.sort_values(ascending=False)
                held_long = _refresh_leg(desc, held_long, n_target, n_exit)
                if not long_only:
                    asc = row.sort_values(ascending=True)
                    held_short = _refresh_leg(asc, held_short, n_target, n_exit, exclude=held_long)
        if held_long:
            long_mask.loc[dt, list(held_long)] = True
        if held_short:
            short_mask.loc[dt, list(held_short)] = True
    return reweight_selection(sig.ffill(), long_mask, None if long_only else short_mask, scheme, scale, max_weight)


def _refresh_leg(ordered: Series, held: set, n_target: int, n_exit: int, exclude: Optional[set] = None) -> set:
    """Keep held names still inside the top ``n_exit`` of ``ordered``; top up to ``n_target`` best-first."""
    exclude = exclude or set()
    names = [s for s in ordered.index if s not in exclude]
    inside_band = set(names[:n_exit])
    keep = [s for s in names if s in held and s in inside_band]
    if len(keep) > n_target:  # the eligible universe shrank: drop the weakest of the kept names
        keep = keep[:n_target]
    for s in names:
        if len(keep) >= n_target:
            break
        if s not in keep:
            keep.append(s)
    return set(keep)


__all__ = ["SCHEMES", "trailing_volatility", "position_weights", "buffered_weights", "reweight_selection"]
