"""Portfolio construction: weights, constituent returns, schedules and signal-to-weights.

from analytics.portfolio import quantile_weights, rebalance_dates
from analytics.portfolio import position_weights, buffered_weights, long_only_weights, tilt_weights
from analytics.portfolio.weights import calculate_portfolio_constituent_weights

Modules:
    long_short   quantile_weights (equal-weight top / bottom quantile), cap_weights, leg_returns
    sizing       position_weights (equal / score / rank / inverse_vol / market_cap), buffered_weights,
                 trailing_volatility
    long_only    long_only_weights, tilt_weights (enhanced index), cap_sector_weights, active_weights
    membership   membership_matrix (point-in-time universe as a boolean date x security frame)
    schedule     rebalance_dates, month_starts, quarter_starts
    weights      constituent weights for stored portfolios (market / equal / price weighted)
    returns      constituent returns for stored portfolios
"""

from .long_only import active_weights, cap_sector_weights, clip_active_weights, long_only_weights, sector_weights, tilt_weights
from .long_short import cap_weights, leg_returns, quantile_weights
from .membership import membership_matrix
from .returns import calculate_portfolio_constituent_returns, merge_returns_with_weights
from .schedule import month_starts, quarter_starts, rebalance_dates
from .sizing import SCHEMES, buffered_weights, position_weights, reweight_selection, trailing_volatility
from .weights import calculate_held_shares, calculate_portfolio_constituent_weights

__all__ = [
    "quantile_weights",
    "cap_weights",
    "leg_returns",
    "position_weights",
    "buffered_weights",
    "reweight_selection",
    "trailing_volatility",
    "SCHEMES",
    "long_only_weights",
    "tilt_weights",
    "active_weights",
    "clip_active_weights",
    "cap_sector_weights",
    "sector_weights",
    "membership_matrix",
    "rebalance_dates",
    "month_starts",
    "quarter_starts",
    "calculate_portfolio_constituent_returns",
    "merge_returns_with_weights",
    "calculate_portfolio_constituent_weights",
    "calculate_held_shares",
]
