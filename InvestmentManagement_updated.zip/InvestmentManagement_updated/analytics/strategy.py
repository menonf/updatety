"""One declarative definition of a factor strategy, shared by backtests and live screens.

Notebooks 04 and 05 each used to restate the strategy (factor list, blend
weights, quantile, ...) in their own parameter cells - and had drifted apart
(04 blended momentum / ML value 50:50, 05 used 30:70, so the screen was not
trading the book that was backtested). A :class:`StrategyConfig` is the single
source of truth:

    from analytics.strategy import StrategyConfig, SignalSpec, compute_signals, build_weights

    cfg = StrategyConfig(
        name="MOM_MLV_LS",
        signals=[SignalSpec("momentum", "momentum", 0.5, {"lookback": 252, "skip": 21}),
                 SignalSpec("ml_value", "ml_value", 0.5, {"mode": "ensemble"})],
        quantile=0.10, rebalance="M", cost_bps=10,
    )
    signals   = compute_signals(cfg, prices, rebalances, provider=provider, symbols=symbols, model_dir=MODEL_DIR)
    composite = blend(cfg, signals, rebalances)
    weights   = build_weights(cfg, composite, membership)
    result    = run_backtest(weights, prices_to_returns(prices), shift_weights=1, cost_bps=cfg.cost_bps)

Adding a factor to the strategy is one more ``SignalSpec``; a factor class is
looked up by name in ``analytics.factors.registry`` (``register_factor`` adds
your own). Configs round-trip through ``to_dict`` / ``from_dict`` / ``save`` /
``load`` so the exact definition can live next to the exported screens.
"""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from typing import Any, Callable, Optional

import pandas as pd
from pandas import DataFrame

from analytics.factors import Factor, PanelFactor, registry
from analytics.factors.library import RatioCompositeFactor, RatioSpec
from analytics.factors.transforms import combine, sample_on
from analytics.portfolio.sizing import SCHEMES, buffered_weights, position_weights

PanelFn = Callable[[Any], Optional[DataFrame]]


@dataclass
class SignalSpec:
    """One component signal of a strategy.

    Args:
        name: label used in outputs (``momentum``, ``ml_value``, ``growth`` ...).
        factor: key in ``analytics.factors.registry`` (``"momentum"``,
            ``"value"``, ``"quality"``, ``"growth"``, ``"ml_value"``,
            ``"ratio_composite"`` or a name you registered).
        weight: blend weight (normalised across signals at use).
        params: keyword arguments for the factor class. For
            ``ratio_composite`` pass ``{"specs": [RatioSpec.to_dict(), ...]}``.
        refresh: ``"rebalance"`` (default) re-scores a fundamentals factor on
            the rebalance dates and forward-fills; ``"daily"`` re-scores every
            price date (slow, exact).
    """

    name: str
    factor: str
    weight: float = 1.0
    params: dict[str, Any] = field(default_factory=dict)
    refresh: str = "rebalance"

    def build(self, **runtime: Any) -> Factor:
        """Instantiate the factor.

        ``runtime`` kwargs (e.g. ``model_dir`` for the ML factor) are passed on
        only when the factor class accepts them and ``params`` does not already
        set them, so one call site can serve every factor type.
        """
        import inspect

        key = self.factor.lower()
        if key not in registry:
            raise KeyError(f"Unknown factor '{self.factor}' for signal '{self.name}'. Available: {sorted(registry)}")
        cls = registry[key]
        params = dict(self.params)
        if key == "ratio_composite" and "specs" in params:
            params["specs"] = [RatioSpec.from_dict(spec) if isinstance(spec, dict) else spec for spec in params["specs"]]
        if runtime:
            accepted = inspect.signature(cls.__init__).parameters
            params.update({k: v for k, v in runtime.items() if k in accepted and k not in params})
        return cls(**params)


@dataclass
class StrategyConfig:
    """Everything that defines a factor book, from signals to sizing.

    Args:
        name: strategy label (used as the backtest column / screen file stem).
        signals: component signals and their blend weights.
        blend_method: ``"zscore"`` or ``"rank"`` cross-sectional transform before blending.
        missing: value for a component missing on a security (``0`` = neutral; ``None`` = drop the name).
        rebalance: ``"D"``, ``"W"``, ``"M"`` or ``"Q"`` refresh of the composite.
        quantile: fraction of eligible names per leg.
        long_only: build only the long leg.
        position_weighting: ``"equal"``, ``"score"``, ``"rank"``, ``"inverse_vol"`` or ``"market_cap"``.
        max_weight: optional per-name cap.
        exit_quantile: when set (> ``quantile``) a holding buffer is applied (see ``buffered_weights``).
        min_names: minimum eligible names for a book to be formed.
        cost_bps: one-way transaction cost per unit turnover (backtest).
        availability_lag_days: publication lag applied to fundamentals (provider setting, recorded here).
        require_all: live screen - drop names lacking any component instead of scoring the gap as neutral.
        universe: label of the eligible universe (``"SP500"``).
    """

    name: str
    signals: list[SignalSpec]
    blend_method: str = "zscore"
    missing: Optional[float] = 0.0
    rebalance: str = "M"
    quantile: float = 0.10
    long_only: bool = False
    position_weighting: str = "equal"
    max_weight: Optional[float] = None
    exit_quantile: Optional[float] = None
    min_names: int = 20
    cost_bps: float = 10.0
    availability_lag_days: int = 45
    require_all: bool = True
    universe: str = "SP500"

    def __post_init__(self) -> None:
        """Validate the definition."""
        if not self.signals:
            raise ValueError("a strategy needs at least one signal")
        names = [s.name for s in self.signals]
        if len(set(names)) != len(names):
            raise ValueError(f"duplicate signal names: {names}")
        if self.position_weighting not in SCHEMES:
            raise ValueError(f"position_weighting must be one of {SCHEMES}")
        if not 0 < self.quantile <= 0.5:
            raise ValueError("quantile must be in (0, 0.5]")
        if self.exit_quantile is not None and not self.quantile <= self.exit_quantile <= 0.5:
            raise ValueError("exit_quantile must satisfy quantile <= exit_quantile <= 0.5")
        self.signals = [SignalSpec(**s) if isinstance(s, dict) else s for s in self.signals]

    # -- derived -----------------------------------------------------------------

    def weights(self) -> dict[str, float]:
        """``signal name -> blend weight``."""
        return {s.name: float(s.weight) for s in self.signals}

    def needs_growth_metrics(self) -> bool:
        """True when any signal reads a ``GROWTH_COLUMNS`` metric (build the provider with ``metric_columns=METRIC_COLUMNS``)."""
        for spec in self.signals:
            try:
                factor = spec.build()
            except Exception:  # noqa: BLE001 - e.g. ML models not on disk; growth is a ratio factor anyway
                continue
            if isinstance(factor, RatioCompositeFactor) and factor.requires_growth_metrics():
                return True
        return False

    def describe(self) -> DataFrame:
        """One row per signal: factor, weight, params."""
        rows = [{"signal": s.name, "factor": s.factor, "weight": s.weight, "params": s.params} for s in self.signals]
        return DataFrame(rows).set_index("signal")

    # -- persistence -------------------------------------------------------------

    def to_dict(self) -> dict[str, Any]:
        """JSON-friendly representation."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "StrategyConfig":
        """Inverse of :meth:`to_dict`."""
        payload = dict(data)
        payload["signals"] = [SignalSpec(**s) if isinstance(s, dict) else s for s in payload["signals"]]
        return cls(**payload)

    def save(self, path: str) -> str:
        """Write the config as JSON; returns ``path``."""
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(self.to_dict(), fh, indent=2, default=str)
        return path

    @classmethod
    def load(cls, path: str) -> "StrategyConfig":
        """Read a config written by :meth:`save`."""
        with open(path, "r", encoding="utf-8") as fh:
            return cls.from_dict(json.load(fh))

    def with_updates(self, **changes: Any) -> "StrategyConfig":
        """Copy with some fields replaced (``cfg.with_updates(long_only=True, quantile=0.2)``)."""
        data = self.to_dict()
        data.update(changes)
        return StrategyConfig.from_dict(data)


# ---------------------------------------------------------------------------
# Running a config
# ---------------------------------------------------------------------------


def compute_signals(
    config: StrategyConfig,
    prices: DataFrame,
    rebalances: Optional[pd.DatetimeIndex] = None,
    provider: Any = None,
    symbols: Optional[DataFrame] = None,
    window: Optional[tuple[Any, Any]] = None,
    **runtime: Any,
) -> dict[str, DataFrame]:
    """Compute every component signal of ``config`` as a date x security_id frame.

    Args:
        prices: adjusted close panel (may start before the strategy window so
            momentum is defined on day one).
        rebalances: dates on which fundamentals factors are re-scored
            (``refresh="rebalance"``); default every price date.
        provider: fundamentals provider with ``get_panel(symbols, "YYYY-MM-DD")``
            (point-in-time). Required when a signal is a ``PanelFactor``.
        symbols: ``security_id`` frame passed to the provider (default: all price columns).
        window: optional ``(start, end)`` to trim the output (prices before
            ``start`` are still used as history).
        **runtime: extra constructor kwargs offered to every factor that
            accepts them, e.g. ``model_dir=...`` for the ML factor.
    """
    syms = symbols if symbols is not None else DataFrame({"security_id": prices.columns})
    out: dict[str, DataFrame] = {}
    for spec in config.signals:
        factor = spec.build(**runtime)
        if isinstance(factor, PanelFactor):
            if provider is None:
                raise ValueError(f"signal '{spec.name}' needs a fundamentals provider")
            if isinstance(factor, RatioCompositeFactor) and factor.requires_growth_metrics():
                served = getattr(provider, "metric_columns", None)
                if served is not None and not set(factor.columns) <= set(served):
                    raise ValueError(
                        f"signal '{spec.name}' reads growth metrics {factor.columns} but the provider only serves {list(served)}; "
                        "build it with metric_columns=METRIC_COLUMNS"
                    )
            dates = None if spec.refresh == "daily" else rebalances
            sig = factor.compute_dynamic(prices, lambda d: provider.get_panel(syms, pd.Timestamp(d).strftime("%Y-%m-%d")), dates=dates)
        else:
            sig = factor.compute(prices)
        out[spec.name] = sig.loc[window[0] : window[1]] if window else sig
    return out


def blend(config: StrategyConfig, signals: dict[str, DataFrame], rebalances: Optional[pd.DatetimeIndex] = None) -> DataFrame:
    """Blend component signals with the config's weights / method and sample on the rebalance dates."""
    composite = combine(signals, config.weights(), method=config.blend_method, missing=config.missing)
    return sample_on(composite, pd.DatetimeIndex(rebalances)) if rebalances is not None else composite


def build_weights(
    config: StrategyConfig,
    composite: DataFrame,
    membership: Optional[DataFrame] = None,
    scale: Optional[DataFrame] = None,
    rebalances: Optional[pd.DatetimeIndex] = None,
) -> DataFrame:
    """Turn the composite into target weights following the config's sizing rules."""
    if config.exit_quantile is not None and config.exit_quantile > config.quantile:
        return buffered_weights(
            composite,
            config.quantile,
            config.exit_quantile,
            long_only=config.long_only,
            dates=rebalances,
            membership=membership,
            min_names=config.min_names,
            scheme=config.position_weighting,
            scale=scale,
            max_weight=config.max_weight,
        )
    return position_weights(
        composite,
        config.quantile,
        long_only=config.long_only,
        scheme=config.position_weighting,
        membership=membership,
        min_names=config.min_names,
        max_weight=config.max_weight,
        scale=scale,
    )


# ---------------------------------------------------------------------------
# Presets (edit here, and both the backtest and the screen follow)
# ---------------------------------------------------------------------------

MOMENTUM_ML_VALUE_LONG_SHORT = StrategyConfig(
    name="COMPOSITE_LS",
    signals=[
        SignalSpec("momentum", "momentum", 0.5, {"lookback": 252, "skip": 21}),
        SignalSpec("ml_value", "ml_value", 0.5, {"mode": "ensemble", "score_missing": False}),
    ],
    quantile=0.10,
    rebalance="M",
    cost_bps=10,
)

#: Long-only sibling: top quintile, score-weighted, 5 % cap, 15 % exit band.
MOMENTUM_ML_VALUE_LONG_ONLY = StrategyConfig(
    name="COMPOSITE_LO",
    signals=[
        SignalSpec("momentum", "momentum", 0.4, {"lookback": 252, "skip": 21}),
        SignalSpec("ml_value", "ml_value", 0.4, {"mode": "ensemble", "score_missing": False}),
        SignalSpec("growth", "growth", 0.2, {}),
    ],
    quantile=0.20,
    exit_quantile=0.30,
    long_only=True,
    position_weighting="score",
    max_weight=0.05,
    rebalance="M",
    cost_bps=10,
)

__all__ = [
    "SignalSpec",
    "StrategyConfig",
    "compute_signals",
    "blend",
    "build_weights",
    "MOMENTUM_ML_VALUE_LONG_SHORT",
    "MOMENTUM_ML_VALUE_LONG_ONLY",
]
