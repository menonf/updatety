"""Transparent (non-ML) value factor built from the fundamentals ratio panel.

``ValueFactor`` is the *value preset* of :class:`~analytics.factors.library.RatioCompositeFactor`:
each price multiple is inverted into a yield (E/P, B/P, S/P, EBIT/EV),
non-positive multiples are treated as missing, yields are winsorised and
z-scored across the cross-section, and the available components are averaged.
Higher = cheaper. The numbers are identical to the original hand-written
implementation; what changed is that the definition is now data:

    ValueFactor()                                           # the four default multiples
    ValueFactor(metrics=["P/E", "P/B"])                     # a subset
    ValueFactor(extra=[RatioSpec("EV/EBITDA", transform="inverse", positive_only=True)])
    ValueFactor(drop=["P/S"], extra=[RatioSpec("Book Equity/TL")])
"""

from __future__ import annotations

from typing import Iterable, Optional, Sequence

from pandas import DataFrame

from data_engineering.fundamentals.ratios import VALUE_MULTIPLES_LOWER_IS_BETTER

from .library import RatioCompositeFactor, RatioSpec

#: Default cheapness measures: price multiples where lower is cheaper.
DEFAULT_VALUE_METRICS: tuple[str, ...] = tuple(VALUE_MULTIPLES_LOWER_IS_BETTER)


class ValueFactor(RatioCompositeFactor):
    """Composite "cheapness" score: mean z-score of inverted price multiples.

    Args:
        metrics: price multiples to invert into yields (default
            ``P/E``, ``P/B``, ``P/S``, ``EV/EBIT``). Each becomes a
            ``RatioSpec(transform="inverse", positive_only=True)``.
        winsor: quantile clip applied to every component (``None`` = off).
        min_components: minimum non-missing components for a score.
        fundamentals: optional static panel for single-argument ``compute``.
        extra: additional :class:`RatioSpec` components (any stored metric,
            any direction / transform) - *this is how you add a ratio*.
        drop: metric names to leave out of ``metrics``.
    """

    name = "value"

    def __init__(
        self,
        metrics: Sequence[str] = DEFAULT_VALUE_METRICS,
        winsor: Optional[tuple[float, float]] = (0.01, 0.99),
        min_components: int = 1,
        fundamentals: Optional[DataFrame] = None,
        extra: Iterable[RatioSpec] = (),
        drop: Iterable[str] = (),
    ):
        """Configure which multiples to use and how to clean them."""
        self.metrics = tuple(m for m in metrics if m not in set(drop))
        self.winsor = winsor
        specs = [RatioSpec(m, direction=1, transform="inverse", positive_only=True, winsor=winsor) for m in self.metrics]
        super().__init__(specs + list(extra), min_components=min_components, name="value", fundamentals=fundamentals)
