"""Declarative fundamentals factors: a factor is a *list of ratio specs*, not code.

Every fundamentals-based factor in this library (value, quality, growth, or
one you define in a notebook) is a :class:`RatioCompositeFactor`: for each
:class:`RatioSpec` it takes one column of the ratio panel, optionally
transforms it (``1/x`` turns a price multiple into a yield), orients it so
that *higher is better*, winsorises the tails, z-scores it across the
cross-section and finally averages the available component scores with the
spec weights. Everything downstream (``compute_dynamic`` point-in-time
re-scoring, ``CompositeFactor`` blending, backtests, screens) is inherited
from :class:`~analytics.factors.base.PanelFactor`.

Adding a ratio to an existing factor::

    ValueFactor(extra=[RatioSpec("EV/EBITDA", transform="inverse", positive_only=True)])

Defining a brand-new factor::

    QUALITY = [RatioSpec("RoE"), RatioSpec("Debt/Equity", direction=-1)]
    quality = RatioCompositeFactor(QUALITY, name="quality")

The metric a spec names must exist in the stored panel. The 18
``RATIO_COLUMNS`` are always there; the ``GROWTH_COLUMNS`` are stored by the
Refinitiv quarterly loader (``include_growth=True``) and served when the
provider is built with ``metric_columns=METRIC_COLUMNS``. A metric outside
both lists means extending ``compute_ratios`` / ``compute_growth_ratios``
first (see README, *Adding a new factor*).
"""

from __future__ import annotations

from dataclasses import dataclass, replace
from typing import Any, Iterable, Optional, Sequence

import numpy as np
from pandas import DataFrame, Series

from data_engineering.fundamentals.ratios import GROWTH_COLUMNS, METRIC_COLUMNS, RATIO_COLUMNS

from .base import PanelFactor
from .transforms import winsorize, zscore

TRANSFORMS = ("raw", "inverse", "log")


@dataclass(frozen=True)
class RatioSpec:
    """How one panel column enters a composite score.

    Args:
        column: metric name in the fundamentals panel (e.g. ``"P/E"``).
        direction: ``+1`` when a higher value is better *after* ``transform``
            (yields, margins, growth), ``-1`` when lower is better (leverage,
            asset growth, share issuance).
        transform: ``"raw"`` (use as is), ``"inverse"`` (``1/x`` - turns a
            price multiple into a yield so that higher = cheaper) or ``"log"``
            (``log(x)``, compresses skewed positive quantities).
        positive_only: treat non-positive values as missing (a negative P/E
            is not "cheap"; a negative multiple has no yield).
        weight: relative weight inside the composite (normalised at use).
        winsor: ``(lower, upper)`` quantiles to clip, or ``None`` to skip.
    """

    column: str
    direction: int = 1
    transform: str = "raw"
    positive_only: bool = False
    weight: float = 1.0
    winsor: Optional[tuple[float, float]] = (0.01, 0.99)

    def __post_init__(self) -> None:
        """Validate the specification."""
        if self.direction not in (1, -1):
            raise ValueError(f"direction must be +1 or -1, got {self.direction}")
        if self.transform not in TRANSFORMS:
            raise ValueError(f"transform must be one of {TRANSFORMS}, got '{self.transform}'")
        if self.weight <= 0:
            raise ValueError("weight must be > 0")

    def oriented(self, values: Series) -> Series:
        """Transform one cross-section so that higher = better (NaN where undefined)."""
        x = values.astype(float)
        if self.positive_only or self.transform in ("inverse", "log"):
            x = x.where(x > 0)
        if self.transform == "inverse":
            x = 1.0 / x
        elif self.transform == "log":
            x = np.log(x)
        return x * self.direction

    def to_dict(self) -> dict[str, Any]:
        """JSON-friendly representation."""
        return {
            "column": self.column,
            "direction": self.direction,
            "transform": self.transform,
            "positive_only": self.positive_only,
            "weight": self.weight,
            "winsor": list(self.winsor) if self.winsor is not None else None,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "RatioSpec":
        """Inverse of :meth:`to_dict`."""
        kwargs = dict(data)
        if kwargs.get("winsor") is not None:
            kwargs["winsor"] = tuple(kwargs["winsor"])
        return cls(**kwargs)


def validate_specs(specs: Iterable[RatioSpec], known: Sequence[str] = METRIC_COLUMNS) -> list[RatioSpec]:
    """Return ``specs`` as a list, raising if a column is not a stored metric or appears twice."""
    out = list(specs)
    if not out:
        raise ValueError("a ratio composite needs at least one RatioSpec")
    unknown = [s.column for s in out if s.column not in known]
    if unknown:
        raise ValueError(f"unknown metric(s) {unknown}; extend compute_ratios / compute_growth_ratios first. Known: {list(known)}")
    seen = [s.column for s in out]
    dupes = sorted({c for c in seen if seen.count(c) > 1})
    if dupes:
        raise ValueError(f"metric(s) specified twice: {dupes}")
    return out


class RatioCompositeFactor(PanelFactor):
    """Weighted mean of z-scored, oriented ratio components (higher = better).

    Args:
        specs: the components (see :class:`RatioSpec`).
        min_components: a security needs at least this many non-missing
            components to receive a score (else NaN).
        name: factor name used in outputs.
        fundamentals: optional static panel for single-argument ``compute``.
        min_winsor_obs: winsorise a component only when it has more than this
            many observations (tiny cross-sections are left untouched).
    """

    name = "ratio_composite"

    def __init__(
        self,
        specs: Iterable[RatioSpec],
        min_components: int = 1,
        name: Optional[str] = None,
        fundamentals: Optional[DataFrame] = None,
        min_winsor_obs: int = 2,
    ):
        """Validate and store the component specification."""
        super().__init__(fundamentals)
        self.specs: list[RatioSpec] = validate_specs(specs)
        self.min_components = int(min_components)
        self.min_winsor_obs = int(min_winsor_obs)
        if name is not None:
            self.name = name

    def __repr__(self) -> str:  # pragma: no cover - cosmetic
        """Compact ``Class(name=..., columns=[...], min_components=n)`` form."""
        return f"{type(self).__name__}(name={self.name!r}, columns={self.columns}, min_components={self.min_components})"

    # -- introspection ---------------------------------------------------------

    @property
    def columns(self) -> list[str]:
        """Panel columns this factor reads."""
        return [s.column for s in self.specs]

    def requires_growth_metrics(self) -> bool:
        """True when any component lives in ``GROWTH_COLUMNS`` (provider needs ``metric_columns=METRIC_COLUMNS``)."""
        return any(s.column in GROWTH_COLUMNS for s in self.specs)

    def with_specs(self, extra: Iterable[RatioSpec] = (), drop: Iterable[str] = ()) -> "RatioCompositeFactor":
        """Return a copy with ``extra`` components added and ``drop`` columns removed."""
        kept = [s for s in self.specs if s.column not in set(drop)]
        return RatioCompositeFactor(kept + list(extra), self.min_components, self.name, self._fundamentals, self.min_winsor_obs)

    def describe(self) -> DataFrame:
        """One row per component: column, direction, transform, weight, positive_only, winsor."""
        return DataFrame([s.to_dict() for s in self.specs]).set_index("column")

    # -- scoring ---------------------------------------------------------------

    def component_scores(self, panel: DataFrame) -> DataFrame:
        """Z-scored, oriented component per security (``security_id x column``); NaN where unavailable."""
        scores = {}
        for spec in self.specs:
            if spec.column not in panel.columns:
                continue
            x = spec.oriented(panel[spec.column])
            if spec.winsor is not None and x.notna().sum() > self.min_winsor_obs:
                x = winsorize(x, *spec.winsor)
            scores[spec.column] = zscore(x)
        if not scores:
            return DataFrame(index=panel.index, dtype=float)
        return DataFrame(scores, index=panel.index)

    def score_panel(self, panel: DataFrame) -> Series:
        """Weighted mean of the available component scores (NaN below ``min_components``)."""
        comps = self.component_scores(panel)
        if comps.empty or comps.shape[1] == 0:
            return Series(np.nan, index=panel.index, dtype=float)
        w = Series({s.column: s.weight for s in self.specs}).reindex(comps.columns)
        weighted = comps.mul(w, axis=1)
        present = comps.notna()
        denom = present.mul(w, axis=1).sum(axis=1).replace(0, np.nan)
        score = weighted.sum(axis=1, min_count=1) / denom
        return score.where(present.sum(axis=1) >= self.min_components)

    # -- persistence -----------------------------------------------------------

    def to_dict(self) -> dict[str, Any]:
        """JSON-friendly representation (``specs``, ``min_components``, ``name``)."""
        return {"name": self.name, "min_components": self.min_components, "specs": [s.to_dict() for s in self.specs]}

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "RatioCompositeFactor":
        """Inverse of :meth:`to_dict`."""
        return cls([RatioSpec.from_dict(d) for d in data["specs"]], data.get("min_components", 1), data.get("name"))


# ---------------------------------------------------------------------------
# Presets. Edit these lists (or pass ``extra`` / ``drop``) to change a factor.
# ---------------------------------------------------------------------------


def _yield_spec(multiple: str, weight: float = 1.0) -> RatioSpec:
    """A price multiple entering as its inverted yield (lower multiple = cheaper = higher score)."""
    return RatioSpec(multiple, direction=1, transform="inverse", positive_only=True, weight=weight)


#: Cheapness: inverted price multiples (E/P, B/P, S/P, EBIT/EV).
VALUE_SPECS: tuple[RatioSpec, ...] = tuple(_yield_spec(m) for m in ("EV/EBIT", "P/E", "P/B", "P/S"))

#: Profitability and balance-sheet strength; leverage and dilution count against.
QUALITY_SPECS: tuple[RatioSpec, ...] = (
    RatioSpec("RoE"),
    RatioSpec("ROCE"),
    RatioSpec("Gross Profit Margin"),
    RatioSpec("EBIT/TA"),
    RatioSpec("Debt/Equity", direction=-1),
    RatioSpec("Asset Growth", direction=-1),
    RatioSpec("Share Issuance", direction=-1),
)

#: Fundamental growth: trailing-twelve-month sales / earnings / EBIT growth and margin expansion.
GROWTH_SPECS: tuple[RatioSpec, ...] = (
    RatioSpec("Revenue Growth"),
    RatioSpec("Earnings Growth"),
    RatioSpec("EBIT Growth"),
    RatioSpec("Gross Margin Change"),
)

#: Named presets available through :func:`preset_specs` and the factor registry.
PRESETS: dict[str, tuple[RatioSpec, ...]] = {"value": VALUE_SPECS, "quality": QUALITY_SPECS, "growth": GROWTH_SPECS}


def preset_specs(name: str) -> list[RatioSpec]:
    """Copy of a preset's specs (``"value"``, ``"quality"`` or ``"growth"``)."""
    key = name.lower()
    if key not in PRESETS:
        raise KeyError(f"unknown preset '{name}'. Available: {sorted(PRESETS)}")
    return [replace(s) for s in PRESETS[key]]


class QualityFactor(RatioCompositeFactor):
    """Quality preset (:data:`QUALITY_SPECS`); ``extra`` / ``drop`` customise it."""

    name = "quality"

    def __init__(
        self,
        specs: Optional[Iterable[RatioSpec]] = None,
        extra: Iterable[RatioSpec] = (),
        drop: Iterable[str] = (),
        min_components: int = 2,
        fundamentals: Optional[DataFrame] = None,
    ):
        """Build from the preset unless ``specs`` is given."""
        base = list(specs) if specs is not None else preset_specs("quality")
        super().__init__([s for s in base if s.column not in set(drop)] + list(extra), min_components, "quality", fundamentals)


class GrowthFactor(RatioCompositeFactor):
    """Growth preset (:data:`GROWTH_SPECS`) on the TTM growth metrics.

    Needs the growth extension in the panel: build the provider with
    ``metric_columns=METRIC_COLUMNS`` and load fundamentals with
    ``include_growth=True`` (the default of the Refinitiv quarterly loader).
    """

    name = "growth"

    def __init__(
        self,
        specs: Optional[Iterable[RatioSpec]] = None,
        extra: Iterable[RatioSpec] = (),
        drop: Iterable[str] = (),
        min_components: int = 1,
        fundamentals: Optional[DataFrame] = None,
    ):
        """Build from the preset unless ``specs`` is given."""
        base = list(specs) if specs is not None else preset_specs("growth")
        super().__init__([s for s in base if s.column not in set(drop)] + list(extra), min_components, "growth", fundamentals)


__all__ = [
    "RatioSpec",
    "RatioCompositeFactor",
    "QualityFactor",
    "GrowthFactor",
    "VALUE_SPECS",
    "QUALITY_SPECS",
    "GROWTH_SPECS",
    "PRESETS",
    "preset_specs",
    "validate_specs",
    "RATIO_COLUMNS",
    "GROWTH_COLUMNS",
    "METRIC_COLUMNS",
]
