# InvestmentManagement

A research, backtesting and analytics platform for equity factor strategies, built on plug-and-play market-data
vendors (Refinitiv / LSEG today; Yahoo, Tiingo, Marketstack, SimFin adapters included) and persistent analytics
storage in SQL Server (or Databricks).

The reference strategy is a **momentum + machine-learning value** composite traded long/short on the S&P 500,
benchmarked against a float-adjusted reconstruction of the index, the SPY ETF and the ^GSPC index level.

## Why systematic investing

Beating a market index consistently is hard, and the hardest part is not finding an idea - it is executing it
without your own behaviour getting in the way. Discretionary investors must decide *what* to buy, *when* to
rebalance, and *how much* to hold on every single day, and studies of real accounts repeatedly show that the
average person underperforms the very funds they hold because they chase recent winners and sell into panic.

A systematic process removes that human loop from the hot path:

- **Rules, not moods.** The position on every rebalance date is computed from the same formula, so you cannot
  talk yourself out of a sensible trade or into a story-driven one.
- **Scale beyond human capacity.** A single rebalance across the S&P 500 means weighing 500+ stocks on dozens
  of fundamentals and price signals each - far more than any person can compare by hand or hold in their head,
  so a disciplined human inevitably narrows to a familiar handful and leaves the rest uninvestigated. The engine
  scores every name every time, with no fatigue and no home-team bias.
- **Point-in-time discipline.** The engine only ever uses information that was knowable on the rebalance date
  (no peeking at future fundamentals or prices), which is the difference between a backtest you can trust and a
  backtest that lies to you.
- **Costs and turnover are first-class.** Every simulation charges realistic transaction costs and shifts the
  signal by one period, so quoted returns are what you could actually have booked.
- **Reproducible and auditable.** A run is a function of data plus code; anyone (including you, six months later)
  can re-run it, challenge it, and improve it.

This repository is that process made concrete: loaders that gather clean, point-in-time data, an analytics core
that turns it into factors and portfolios, and notebooks that walk from raw prices to a live long/short book.

## Layout

```
analytics/                 vendor-agnostic research engine (pure pandas / numpy / scikit-learn)
  factors/                 Factor & PanelFactor contracts, MomentumFactor, MLReturnFactor, CompositeFactor,
                           library (RatioSpec / RatioCompositeFactor + Value / Quality / Growth presets),
                           transforms (zscore / rank / winsorize / neutralize), ml_training
  strategy.py              StrategyConfig / SignalSpec: one declarative strategy definition shared by
                           backtests (04A) and live screens (05A); compute_signals / blend / build_weights
  portfolio/               constituent weights & returns, rebalance schedules, quantile long/short weights,
                           sizing (equal / score / rank / inverse-vol / market-cap, holding buffer),
                           long_only (benchmark tilt, sector caps, active weights), membership matrix
  backtest/                run_backtest, BacktestResult, performance metrics (incl. active return / IR),
                           IC / quantile diagnostics
  screening.py             dated screens: build_screen (L/S or long-only, position weighting), enrichment,
                           size_positions (capital -> shares), trade_list (orders incl. resizes)
  performance/             plots (+ legacy performance_analytics facade)
  risk/                    PortfolioVaR (historical & parametric)
  data_quality.py          glitch detection / neutralisation for price panels
data_engineering/          everything that touches a vendor or the database
  refinitiv/               shared LSEG plumbing: lazy session, RIC helpers, chunked + retried requests
  eod_data/                PriceVendor base + Refinitiv / Yahoo / Tiingo / Marketstack price vendors
  fundamentals/            18-ratio ML contract + growth extension (GROWTH_COLUMNS) + providers: database
                           (point-in-time), Refinitiv (quarterly history incl. growth), Yahoo, in-memory
  index_constituents/      index membership reconstruction + float-adjusted shares (Refinitiv)
  security_master/         security master ingestion (Refinitiv, FinanceDatabase)
  loaders/                 pipelines: portfolios & holdings, backtest universe, batched EOD load, fundamentals
                           load, incremental daily / monthly refresh (membership diff, holdings, prices,
                           fundamentals diff-and-upsert)
  database/                ORM models, connection factory, read_* / write_* helpers (SQL Server + Databricks)
toolkit/notebooks/         numbered walk-throughs (see below)
toolkit/scripts/           command-line loaders (incl. the schedulable incremental_load.py)
tests/unit_tests/          pytest suite (runs without a database or vendor)
docs/                      REFACTORING_NOTES.md, STRATEGY_IMPROVEMENTS.md, INCREMENTAL_LOADS_AND_LONG_ONLY.md
```

Design rule: **`analytics` never imports a vendor or the database.** It consumes two standard shapes -
a *price panel* (`DataFrame`, index = date, columns = `security_id`) and a *fundamentals panel*
(index = `security_id`, columns = the 18 `RATIO_COLUMNS`, optionally widened with the `GROWTH_COLUMNS`) -
so any vendor that fills those shapes works.

## Getting started

```sh
git clone https://github.com/menonf/InvestmentManagement.git
cd InvestmentManagement
python -m venv .venv && .venv\Scripts\activate          # Windows; use source .venv/bin/activate elsewhere
pip install -e .[refinitiv,dev]                          # editable install: no sys.path hacks anywhere
pytest                                                   # 60+ offline unit tests
```

Database credentials live in the OS keyring under `ihub_sql_connection` (`db`, `uid`, `pwd`; optionally
`server` + `trusted=1` for a local instance). Refinitiv needs LSEG Workspace running; the session opens lazily.

## Notebooks

Run them in order the first time to build the live dataset; `06` runs on synthetic data anywhere. The **A**
notebooks are the operating versions: `01A` / `03A` keep the data current (daily or monthly - the window comes from
the last loaded date), `04A` / `05A` are the long-only backtest and screen built on one shared `StrategyConfig`.

| # | Notebook | Needs | What it does |
|---|---|---|---|
| 1 | [01_load_reference_data_and_prices.ipynb](toolkit/notebooks/01_load_reference_data_and_prices.ipynb) | DB + LSEG | Loads `.SPX` membership, float-adjusted shares and four base portfolios (SP500 / SPY / GSPC / MAG8), then runs the batched, retried EOD price load with mop-up and holiday pruning. |
| 1A | [01A_refresh_reference_data_and_prices.ipynb](toolkit/notebooks/01A_refresh_reference_data_and_prices.ipynb) | DB + LSEG | **Incremental refresh**: detects index constitution changes (joiners / leavers vs the stored open intervals, exact dates from LSEG events), closes / opens membership intervals, appends holdings for the new dates only, merges float shares and prices for the window, reports gaps against the inferred trading calendar. `DRY_RUN` shows the diff without writing. |
| 2 | [02_backtest_sp500_reconstruction.ipynb](toolkit/notebooks/02_backtest_sp500_reconstruction.ipynb) | DB | Reconstructs the S&P 500 under market / equal / mixed weighting and checks it against ^GSPC and SPY (tracking error, drawdowns, VaR). |
| 3 | [03_load_ml_value_fundamentals.ipynb](toolkit/notebooks/03_load_ml_value_fundamentals.ipynb) | DB + LSEG | Loads the point-in-time quarterly history of the 18 fundamental ratios per security (plus the growth metrics), with per-security retries and a no-look-ahead audit. |
| 3A | [03A_refresh_fundamentals.ipynb](toolkit/notebooks/03A_refresh_fundamentals.ipynb) | DB + LSEG | **Incremental refresh**: re-pulls the last two fiscal quarters, diffs them against the database and upserts only new periods / new cells / restatements; reports which securities published a new quarter and whether the persisted ML models should be retrained. |
| 4 | [04_momentum_ml_value_long_short.ipynb](toolkit/notebooks/04_momentum_ml_value_long_short.ipynb) | DB | Trains the ML value model on a time-based split, scores point-in-time, and builds the composite momentum+value long/short with costs and IC / quintile diagnostics. |
| 4A | [04A_momentum_ml_value_long_only.ipynb](toolkit/notebooks/04A_momentum_ml_value_long_only.ipynb) | DB | **Long-only** books from one `StrategyConfig` (momentum + ML value + growth): equal / score-weighted top quintile, holding buffer, sector caps and a benchmark tilt (enhanced index), compared with the cap-weighted SP500 on active return, tracking error and information ratio. |
| 5 | [05_stock_screen_long_short.ipynb](toolkit/notebooks/05_stock_screen_long_short.ipynb) | DB | Runs the trained composite on the latest data and shows what the strategy would long and short *today*; now with position weighting (equal / score / rank / inverse-vol / market-cap), optional capital sizing and an order list. |
| 5A | [05A_stock_screen_long_only.ipynb](toolkit/notebooks/05A_stock_screen_long_only.ipynb) | DB | **Long-only screen** for the `StrategyConfig` backtested in 04A: sized holdings (money and shares for a given capital), sector weights vs the index, watch-list and the full order list versus the previous screen, including resizes. |
| 6 | [06_factor_research_offline_demo.ipynb](toolkit/notebooks/06_factor_research_offline_demo.ipynb) | nothing | Exercises the entire engine end-to-end on synthetic data - runs anywhere, ships with outputs - to demonstrate the analytics core without a vendor or database. |

## Ten lines of research code

```python
from analytics.backtest import prices_to_returns, run_backtest
from analytics.factors import CompositeFactor, MomentumFactor, ValueFactor
from analytics.portfolio import month_starts, quantile_weights

rebalances = month_starts(prices.index)
momentum = MomentumFactor(252, 21).compute(prices)
value = ValueFactor().compute_dynamic(prices, lambda d: provider.get_panel(symbols, str(d.date())), dates=rebalances)
signal = CompositeFactor({"momentum": momentum, "value": value}, rebalance_dates=rebalances).compute(prices)
weights = quantile_weights(signal, quantile=0.1, membership=membership)
result = run_backtest(weights, prices_to_returns(prices), shift_weights=1, cost_bps=10)
result.summary()
```

The same strategy as *data*, so the backtest and the live screen cannot drift apart:

```python
from analytics.strategy import StrategyConfig, SignalSpec, compute_signals, blend, build_weights

cfg = StrategyConfig("MOM_VAL_GROWTH_LO",
                     signals=[SignalSpec("momentum", "momentum", 0.4, {"lookback": 252, "skip": 21}),
                              SignalSpec("value", "value", 0.3),
                              SignalSpec("growth", "growth", 0.3)],
                     quantile=0.2, long_only=True, position_weighting="score", max_weight=0.05, exit_quantile=0.3)
signals = compute_signals(cfg, prices, rebalances, provider=provider)      # provider serves METRIC_COLUMNS for growth
weights = build_weights(cfg, blend(cfg, signals, rebalances), membership, rebalances=rebalances)
cfg.save("strategy.json")                                                  # and 05A reloads exactly this definition
```

## Adding a new factor

Fundamentals factors are **lists of `RatioSpec`**, not code (`analytics/factors/library.py`). A spec names a stored
metric, says which direction is good and how to transform it; `RatioCompositeFactor` orients, winsorises,
z-scores and averages the components, and everything downstream (point-in-time re-scoring, `CompositeFactor`
blending, `StrategyConfig`, backtests, screens) is inherited.

```python
from analytics.factors import RatioSpec, RatioCompositeFactor, ValueFactor, GrowthFactor, register_factor
from analytics.strategy import SignalSpec

ValueFactor(extra=[RatioSpec("Book Equity/TL")])                       # add a ratio to value - one line
ValueFactor(drop=["P/S"])                                              # or remove one
GrowthFactor(extra=[RatioSpec("Asset Growth", direction=-1)])          # growth with an investment penalty

leverage = RatioCompositeFactor(                                       # a brand-new factor, usable right away
    [RatioSpec("Debt/Equity", direction=-1), RatioSpec("Op. In./Interest Expense", transform="log")],
    name="balance_sheet",
)
# in a StrategyConfig the same factor is pure data - no class, no registration:
SignalSpec("balance_sheet", "ratio_composite", 0.2, {"specs": [s.to_dict() for s in leverage.specs], "name": "balance_sheet"})
# a factor implemented as a class (price-based or otherwise) is registered once and then addressed by name:
register_factor("my_factor", MyFactor)                                  # -> SignalSpec("mine", "my_factor", ...)
```

- `direction=+1` means higher is better *after* the transform (`"raw"`, `"inverse"` = 1/x for price multiples,
  `"log"`); `positive_only=True` treats non-positive values as missing (a negative P/E is not cheap).
- Presets: `VALUE_SPECS`, `QUALITY_SPECS`, `GROWTH_SPECS` (`ValueFactor` / `QualityFactor` / `GrowthFactor`).
  `ValueFactor()` reproduces the previous hand-written implementation to the last decimal (unit-tested).
- Price-based factors (momentum, volatility, ...) still subclass `Factor` and implement
  `compute(prices, fundamentals=None) -> DataFrame`; register them with `register_factor`.
- **The data contract.** The 18 `RATIO_COLUMNS` are the ML feature contract and never change. The
  `GROWTH_COLUMNS` (TTM revenue / earnings / EBIT growth, gross-margin change, asset growth, share issuance) are
  derived by `compute_growth_ratios` from the quarterly raw items the Refinitiv pull already returns and stored
  next to the ratios; `METRIC_COLUMNS = RATIO_COLUMNS + GROWTH_COLUMNS` is the storage contract. Providers serve
  the 18 by default and the full set with `metric_columns=METRIC_COLUMNS` - a factor that reads a growth metric
  raises a clear error when the provider does not serve it. Because every factor reads columns **by name**, the
  persisted ML models keep working untouched.
- A metric outside `METRIC_COLUMNS` (accruals, capex efficiency, ...) means extending the pipeline first: add the
  raw item to `RAW_ITEMS` and `REFINITIV_REQUEST_FIELDS`, the formula to `compute_ratios` /
  `compute_growth_ratios`, the name to `GROWTH_COLUMNS` (or a new list folded into `METRIC_COLUMNS`), reload
  fundamentals (03 / 03A). Retrain the ML models only if you want *them* to use it.

## Command-line loaders

```sh
python toolkit/scripts/incremental_load.py --fundamentals          # daily (after the close) or monthly refresh of
                                                                   # membership, holdings, float shares, prices and ratios
python toolkit/scripts/incremental_load.py --dry-run               # report the membership diff and the window only
python toolkit/scripts/load_refinitiv_fundamentals.py --universe SP500 --frequency Q --start 2020-01-01
python toolkit/scripts/load_float_adjusted_shares.py
python toolkit/scripts/repair_eod_prices.py 2025-01-01 2025-12-31
python toolkit/scripts/portfolio_data_load.py --portfolios SP500 SPY --start 2025-01-01 --end 2025-06-30
```

`incremental_load.py` exits 0 when everything loaded, 2 when some names are still missing prices or ratios (details
in the log) and 1 on error, so a scheduler can alert on it. Design notes and the operating checklist are in
`docs/INCREMENTAL_LOADS_AND_LONG_ONLY.md`.

## Technology

pandas / NumPy / SciPy / scikit-learn for research;</br>SQLAlchemy + pyodbc (SQL Server) or Databricks for storage;</br>
`lseg.data` and Refinitiv Terminal;</br> matplotlib for reporting;</br> `ib_insync` & Interactive Brokers Terminal for held position loads.

## Key differentiators

- **Persistent analytics storage.** Unlike most open-source factor tools that recompute everything from raw
  files each run, the platform persists point-in-time fundamentals and EOD prices in SQL Server (or Databricks),
  so backtests and live scoring read a stable, auditable history rather than re-pulling vendors.
- **Vendor-agnostic by contract.** `analytics` depends only on a price panel and a fundamentals panel. Refinitiv
  is the production source, but Yahoo / Tiingo / Marketstack / SimFin adapters and an in-memory provider are
  already wired in, so swapping a vendor never touches the research engine.
- **Modular and composable.** Factors, portfolio weights, rebalance schedules and backtests are independent
  objects that plug together (see the ten-line example above), so new signals or weighting schemes drop in without
  a rewrite.

## Roadmap

Short-term (build out the data and signal layer):

- Extend index reconstructions beyond the S&P 500 (e.g. Nasdaq 100) and broaden the backtest "what-if" tooling.
- Harden the fundamentals coverage and no-look-ahead audit so more vendors can feed the ML value factor.

Medium / long-term direction:

- Layer style, country, industry and thematic factor exposures on top of the current growth & momentum base.
- Add an explicit value factor framing to surface securities trading below intrinsic value.
- Combine the above into a growth-at-a-reasonable-price (GARP) strategy and, eventually, run live capital
  through the framework via the Interactive Brokers integration.

## Reference reading that shaped the strategy:
* *Quantitative Momentum* (Wes Gray)</br>
* *Quantitative Value*(Wes Gray & Tobias Carlisle)</br>
* *The Intelligent Investor* (Benjamin Graham)</br>
* *Factor Investing for Dummies*</br>
* *Build Your Own AI Investor*(Damon Lee)

## Further reading

`docs/STRATEGY_IMPROVEMENTS.md` - prioritised ideas to strengthen the factors and the portfolio.</br>
`docs/INCREMENTAL_LOADS_AND_LONG_ONLY.md` - how the daily / monthly refresh works, the long-only construction
choices, the shared strategy definition, and a list of further improvements.

## Disclaimer

This software is for educational and research purposes only. Past performance does not guarantee future results.
</br>*Built with ❤️ for the quantitative finance community*
