"""Incremental (daily / monthly) refresh of reference data, prices and fundamentals.

Notebooks 01 and 03 build the history from scratch. This module keeps that
history current without reloading it:

Reference data (notebook 01A / ``incremental_load.py``)
    * :func:`check_index_membership` - compare the index's *current* constituent
      list (and the recent joiner / leaver events) with the open membership
      intervals stored in ``reference.index_constituents`` -> :class:`MembershipDiff`.
    * :func:`apply_membership_diff` - close the leavers' intervals, open the
      joiners' (creating ``security_master`` / xref rows for unknown names).
    * :func:`extend_index_holdings` / :func:`extend_constant_holdings` - append
      the daily holdings rows for the new dates only.
    * :func:`refresh_float_shares` - float-adjusted shares for the window (MERGE).
    * :func:`refresh_prices` + :func:`price_gaps` - EOD prices for the window,
      mop-up of names that came back empty, holiday pruning, gap report.

Fundamentals (notebook 03A / ``incremental_load.py``)
    * :func:`load_fundamentals_incremental` - pull the last ``lookback_quarters``
      of ratio history, :func:`diff_fundamentals` against what is stored and
      upsert only the *new* and *restated* cells; reports new fiscal periods
      per security and whether the ML models should be retrained.

Every write is idempotent and the window always overlaps the last loaded
dates by a small buffer, so a run that fails half-way, or a vendor that
corrects a print a day later, is repaired by simply running again. All
pure functions (``price_window``, ``diff_membership``, ``diff_fundamentals``,
``price_gaps_from_frames``) are unit-tested without a database or vendor.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Iterable, Mapping, Optional, Sequence

import numpy as np
import pandas as pd
from pandas import DataFrame, Series

from data_engineering.database import database as db
from data_engineering.fundamentals import METRIC_COLUMNS, get_fundamentals_provider, history_to_long, panel_to_long

from .eod_loader import EodLoadSummary, load_eod_prices, mop_up_missing_prices, prune_low_coverage_holdings
from .portfolios import business_days

log = logging.getLogger(__name__)

UPSERT_BY = "data_engineering.loaders.incremental"
FUNDAMENTAL_KEYS = ["security_id", "metric_type", "effective_date"]


def _today() -> pd.Timestamp:
    return pd.Timestamp.today().normalize()


def _iso(d: Any) -> str:
    return pd.Timestamp(d).strftime("%Y-%m-%d")


# ---------------------------------------------------------------------------
# Windows
# ---------------------------------------------------------------------------


def price_window(
    latest_loaded: Optional[Any],
    as_of: Optional[Any] = None,
    buffer_days: int = 3,
    fallback_days: int = 30,
) -> tuple[str, str]:
    """``(start, end)`` for the next price pull.

    ``start`` is ``buffer_days`` business days before the latest loaded date
    (re-pulling a few days picks up late vendor corrections; the write is an
    upsert so this is free), ``end`` is ``as_of`` (default today). With no
    prior data the window is the last ``fallback_days`` calendar days.
    """
    end = pd.Timestamp(as_of).normalize() if as_of is not None else _today()
    if latest_loaded is None or pd.isna(latest_loaded):
        start = end - pd.Timedelta(days=int(fallback_days))
    else:
        start = pd.Timestamp(latest_loaded).normalize() - pd.tseries.offsets.BDay(int(buffer_days))
    if start >= end:
        start = end - pd.tseries.offsets.BDay(1)
    return _iso(start), _iso(end)


def latest_price_date(engine: Any, security_ids: Optional[Iterable[int]] = None) -> Optional[pd.Timestamp]:
    """Most recent ``as_of_date`` in ``dbo.market_data`` (optionally over a set of securities)."""
    dates = latest_price_dates(engine, security_ids)
    return None if dates.empty else pd.Timestamp(dates.max())


def latest_price_dates(engine: Any, security_ids: Optional[Iterable[int]] = None) -> Series:
    """``security_id -> latest priced date`` from ``dbo.market_data``."""
    import sqlalchemy as sa

    q = "SELECT security_id, MAX(as_of_date) AS last_date FROM dbo.market_data"
    params: dict[str, Any] = {}
    ids = [int(s) for s in security_ids] if security_ids is not None else None
    if ids:
        q += " WHERE security_id IN :ids"
        params["ids"] = ids
    q += " GROUP BY security_id"
    stmt = sa.text(q)
    if ids:
        stmt = stmt.bindparams(sa.bindparam("ids", expanding=True))
    out = pd.read_sql_query(stmt, engine, params=params)
    if out.empty:
        return Series(dtype="datetime64[ns]", name="last_date")
    out["last_date"] = pd.to_datetime(out["last_date"])
    return out.set_index("security_id")["last_date"].sort_index()


def resolve_price_window(engine: Any, as_of: Optional[Any] = None, buffer_days: int = 3, fallback_days: int = 30) -> tuple[str, str]:
    """:func:`price_window` anchored on the database's latest priced date."""
    return price_window(latest_price_date(engine), as_of, buffer_days, fallback_days)


# ---------------------------------------------------------------------------
# Index membership
# ---------------------------------------------------------------------------


@dataclass
class MembershipDiff:
    """Result of comparing stored open membership with the index's current constituents.

    Attributes:
        as_of: date of the constituent snapshot.
        joiners: ``[ric, exchange_ticker, security_id, date]`` - current members
            with no open stored interval (``security_id`` NaN = unknown to the
            security master; created on apply).
        leavers: ``[security_id, exchange_ticker, date]`` - open stored
            intervals whose security is no longer in the index.
        unchanged: number of members present on both sides.
        events: the vendor's joiner / leaver events in the look-back window
            (``[ric, exchange_ticker, date, change]``), used for exact change dates.
    """

    as_of: pd.Timestamp
    joiners: DataFrame
    leavers: DataFrame
    unchanged: int
    events: DataFrame = field(default_factory=DataFrame)

    @property
    def is_empty(self) -> bool:
        """True when membership is unchanged."""
        return self.joiners.empty and self.leavers.empty

    def summary(self) -> dict[str, Any]:
        """Counts for logging / display."""
        return {
            "as_of": self.as_of.date(),
            "joiners": int(len(self.joiners)),
            "leavers": int(len(self.leavers)),
            "unchanged": int(self.unchanged),
            "unresolved_joiners": int(self.joiners["security_id"].isna().sum()) if "security_id" in self.joiners else 0,
        }

    def change_log(self) -> DataFrame:
        """One row per change (``change`` = JOINER / LEAVER) for a CSV export."""
        rows = []
        for r in self.joiners.itertuples(index=False):
            rows.append(
                {"change": "JOINER", "security_id": r.security_id, "ric": r.ric, "exchange_ticker": r.exchange_ticker, "date": r.date}
            )
        for r in self.leavers.itertuples(index=False):
            rows.append(
                {"change": "LEAVER", "security_id": r.security_id, "ric": None, "exchange_ticker": r.exchange_ticker, "date": r.date}
            )
        out = DataFrame(rows, columns=["change", "security_id", "ric", "exchange_ticker", "date"])
        out["as_of"] = self.as_of
        return out


def stored_open_members(engine: Any, index_id: int) -> DataFrame:
    """Open membership intervals (``end_date IS NULL``) for ``index_id``: ``[security_id, exchange_ticker, start_date]``."""
    import sqlalchemy as sa

    q = sa.text(
        "SELECT security_id, exchange_ticker, start_date FROM reference.index_constituents "
        "WHERE index_id = :i AND end_date IS NULL AND security_id IS NOT NULL"
    )
    out = pd.read_sql_query(q, engine, params={"i": int(index_id)})
    out["security_id"] = out["security_id"].astype(int)
    return out.drop_duplicates("security_id").reset_index(drop=True)


def current_index_members(index_ric: str, as_of: Any, exclude_tickers: Optional[frozenset[str]] = None) -> DataFrame:
    """Constituents of ``index_ric`` on ``as_of`` from LSEG: ``[ric, exchange_ticker]`` (futures tickers dropped)."""
    from data_engineering.index_constituents.refinitiv import NON_EQUITY_TICKERS, IndexConstituents

    snap = IndexConstituents().get_constituents_as_of(index_ric, _iso(as_of))
    out = snap.rename(columns={"Constituent RIC": "ric", "Exchange Ticker": "exchange_ticker"})[["ric", "exchange_ticker"]].copy()
    out = out.dropna(subset=["ric"])
    out = out[out["ric"].astype(str).str.len() > 0]
    bad = out["exchange_ticker"].astype(str).str.upper().isin(exclude_tickers if exclude_tickers is not None else NON_EQUITY_TICKERS)
    if bad.any():
        dropped = sorted(out.loc[bad, "exchange_ticker"])
        log.info("dropping %d non-equity ticker(s) from the %s snapshot: %s", int(bad.sum()), index_ric, dropped)
    return out[~bad].drop_duplicates("ric").reset_index(drop=True)


def recent_constituent_events(index_ric: str, start: Any, end: Any) -> DataFrame:
    """Joiner / leaver events for ``index_ric`` in ``[start, end]`` from LSEG: ``[ric, exchange_ticker, date, change]``."""
    from data_engineering.index_constituents.refinitiv import IndexConstituents

    try:
        raw = IndexConstituents().get_constituent_changes(index_ric, _iso(start), _iso(end))
    except Exception as exc:  # noqa: BLE001 - events are a refinement; the snapshot diff still works
        log.warning("constituent change events unavailable (%s); change dates fall back to the snapshot date", exc)
        return DataFrame(columns=["ric", "exchange_ticker", "date", "change"])
    if raw is None or raw.empty:
        return DataFrame(columns=["ric", "exchange_ticker", "date", "change"])
    out = raw.rename(columns={"Constituent RIC": "ric", "Exchange Ticker": "exchange_ticker", "Date": "date", "Change": "change"})
    out = out.reindex(columns=["ric", "exchange_ticker", "date", "change"])
    out["date"] = pd.to_datetime(out["date"], errors="coerce")
    return out.dropna(subset=["ric", "date"]).reset_index(drop=True)


def resolve_rics_to_security_ids(session: Any, engine: Any, rics: Iterable[str], attributes: Optional[DataFrame] = None) -> Series:
    """Read-only ``ric -> security_id`` resolution (exact RIC, normalised RIC, event suffix stripped, then ISIN / SEDOL / CUSIP).

    Mirrors the cascade in ``enrich_with_security_master`` without creating
    rows, so a *check* never writes to the security master. Unresolved RICs
    come back as NaN. ``attributes`` (optional) is the LSEG attribute frame
    with ``Instrument`` and ``ISIN`` / ``SEDOL`` / ``CUSIP`` columns.
    """
    from data_engineering.refinitiv import normalize_ric, strip_event_suffix

    wanted = [str(r) for r in rics]
    out = Series(np.nan, index=pd.Index(wanted, name="ric"), dtype="float64")
    xref = db.read_security_vendor_xref(session, engine, vendor="Refinitiv")
    if not xref.empty:
        xref = xref.dropna(subset=["vendor_ticker"]).sort_values("is_primary", ascending=False)
        exact = xref.drop_duplicates("vendor_ticker").set_index("vendor_ticker")["security_id"]
        xref["_norm"] = xref["vendor_ticker"].map(normalize_ric)
        norm = xref.dropna(subset=["_norm"]).drop_duplicates("_norm").set_index("_norm")["security_id"]
        for ric in wanted:
            base = strip_event_suffix(ric)
            tiers = ((ric, exact), (normalize_ric(ric), norm), (base, exact), (normalize_ric(base), norm))
            for key, table in tiers:
                if key in table.index:
                    out.loc[ric] = float(table.loc[key])
                    break
    missing = out.isna()
    if attributes is not None and missing.any() and "Instrument" in attributes.columns:
        sm = db.read_security_master(session, engine)
        attrs = attributes.drop_duplicates("Instrument").set_index("Instrument")
        for col in ("ISIN", "SEDOL", "CUSIP"):
            if col not in attrs.columns or col.lower() not in sm.columns:
                continue
            ids = sm[col.lower()].astype("string").str.strip().replace({"": pd.NA}).dropna()
            id_map = Series(sm.loc[ids.index, "security_id"].to_numpy(), index=ids.to_numpy())
            id_map = id_map[~id_map.index.duplicated()]
            for ric in out.index[out.isna()]:
                key = attrs[col].get(ric) if ric in attrs.index else None
                if key is not None and pd.notna(key) and str(key).strip() in id_map.index:
                    out.loc[ric] = float(id_map.loc[str(key).strip()])
    return out


def diff_membership(
    stored_open: DataFrame,
    current: DataFrame,
    events: Optional[DataFrame] = None,
    as_of: Optional[Any] = None,
) -> MembershipDiff:
    """Compare stored open intervals with the current constituent list (pure function).

    Args:
        stored_open: ``[security_id, exchange_ticker, ...]`` - open intervals in the database.
        current: ``[ric, exchange_ticker, security_id]`` - today's members with
            ``security_id`` resolved where known (NaN = unknown).
        events: optional ``[ric, exchange_ticker, date, change]`` joiner / leaver
            events; when a change matches an event its ``date`` is used,
            otherwise ``as_of``.
        as_of: snapshot date (default today).
    """
    from data_engineering.refinitiv import normalize_ric

    snap_date = pd.Timestamp(as_of).normalize() if as_of is not None else _today()
    stored = stored_open.copy()
    stored["security_id"] = stored["security_id"].astype(int)
    cur = current.copy()
    cur["security_id"] = pd.to_numeric(cur["security_id"], errors="coerce")
    known_ids = set(cur["security_id"].dropna().astype(int))
    stored_ids = set(stored["security_id"])

    joiner_mask = ~cur["security_id"].isin(stored_ids)
    joiners = cur[joiner_mask][["ric", "exchange_ticker", "security_id"]].copy()
    leavers = stored[~stored["security_id"].isin(known_ids)][["security_id", "exchange_ticker"]].copy()
    unchanged = int(len(known_ids & stored_ids))

    ev = events.copy() if events is not None and not events.empty else DataFrame(columns=["ric", "exchange_ticker", "date", "change"])
    if not ev.empty:
        ev["date"] = pd.to_datetime(ev["date"])
        ev["_norm"] = ev["ric"].astype(str).map(normalize_ric)
        ev["_tick"] = ev["exchange_ticker"].astype(str).str.upper()

    def _event_date(kind: str, ric: Optional[str], ticker: Optional[str]) -> pd.Timestamp:
        if ev.empty:
            return snap_date
        sub = ev[ev["change"].astype(str).str.lower().str.startswith(kind)]
        if ric is not None:
            hit = sub[sub["_norm"] == normalize_ric(str(ric))]
            if len(hit):
                return pd.Timestamp(hit["date"].max()).normalize()
        if ticker is not None and pd.notna(ticker):
            hit = sub[sub["_tick"] == str(ticker).upper()]
            if len(hit):
                return pd.Timestamp(hit["date"].max()).normalize()
        return snap_date

    joiners["date"] = [_event_date("join", r.ric, r.exchange_ticker) for r in joiners.itertuples(index=False)]
    leavers["date"] = [_event_date("leav", None, r.exchange_ticker) for r in leavers.itertuples(index=False)]
    events_out = ev.drop(columns=[c for c in ("_norm", "_tick") if c in ev.columns])
    return MembershipDiff(snap_date, joiners.reset_index(drop=True), leavers.reset_index(drop=True), unchanged, events_out)


def check_index_membership(
    index_ric: str,
    index_id: int,
    session: Any,
    engine: Any,
    as_of: Optional[Any] = None,
    event_lookback_days: int = 45,
) -> MembershipDiff:
    """Read-only membership check: LSEG snapshot + recent events vs stored open intervals."""
    snap_date = pd.Timestamp(as_of).normalize() if as_of is not None else _today()
    current = current_index_members(index_ric, snap_date)
    resolved = resolve_rics_to_security_ids(session, engine, current["ric"].tolist())
    current["security_id"] = current["ric"].map(resolved)
    events = recent_constituent_events(index_ric, snap_date - pd.Timedelta(days=int(event_lookback_days)), snap_date)
    diff = diff_membership(stored_open_members(engine, index_id), current, events, snap_date)
    log.info("membership check %s as of %s: %s", index_ric, snap_date.date(), diff.summary())
    return diff


def apply_membership_diff(
    diff: MembershipDiff, index_id: int, session: Any, engine: Any, create_missing: bool = True
) -> dict[str, Any]:
    """Write a :class:`MembershipDiff`: close the leavers' intervals, open the joiners'.

    Unknown joiners (``security_id`` NaN) are resolved through the full
    cascade of ``enrich_with_security_master`` (which fetches ISIN / SEDOL /
    CUSIP from LSEG and creates ``security_master`` + xref rows when nothing
    matches) unless ``create_missing=False``, in which case they are skipped
    and reported.
    """
    import sqlalchemy as sa

    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    closed = 0
    if not diff.leavers.empty:
        stmt = sa.text(
            "UPDATE reference.index_constituents SET end_date = :d, upsert_date = :u, upsert_by = :b "
            "WHERE index_id = :i AND security_id = :s AND end_date IS NULL"
        )
        for r in diff.leavers.itertuples(index=False):
            res = session.execute(stmt, {"d": _iso(r.date), "u": now, "b": UPSERT_BY, "i": int(index_id), "s": int(r.security_id)})
            closed += int(getattr(res, "rowcount", 0) or 0)
        session.commit()

    joiners = diff.joiners.copy()
    skipped: list[str] = []
    if not joiners.empty:
        unresolved = joiners["security_id"].isna()
        if unresolved.any():
            if create_missing:
                from data_engineering.index_constituents.refinitiv import enrich_with_security_master, fetch_constituent_attributes

                frame = DataFrame(
                    {
                        "Constituent RIC": joiners.loc[unresolved, "ric"].to_numpy(),
                        "Exchange Ticker": joiners.loc[unresolved, "exchange_ticker"].to_numpy(),
                        "Start Date": joiners.loc[unresolved, "date"].to_numpy(),
                        "End Date": None,
                    }
                )
                try:
                    attributes = fetch_constituent_attributes(frame["Constituent RIC"].tolist())
                    frame = frame.merge(attributes, left_on="Constituent RIC", right_on="Instrument", how="left")
                except Exception as exc:  # noqa: BLE001 - attributes only improve matching
                    log.warning("constituent attributes unavailable (%s); resolving on RIC only", exc)
                enriched = enrich_with_security_master(frame, session=session, engine=engine, index_id=index_id)
                ids = enriched.drop_duplicates("Constituent RIC").set_index("Constituent RIC")["security_id"]
                joiners.loc[unresolved, "security_id"] = joiners.loc[unresolved, "ric"].map(ids).astype("float64")
            else:
                skipped = joiners.loc[unresolved, "ric"].tolist()
                joiners = joiners[~unresolved]
        joiners = joiners.dropna(subset=["security_id"])
        rows = [
            {
                "index_id": int(index_id),
                "security_id": int(r.security_id),
                "exchange_ticker": str(r.exchange_ticker) if pd.notna(r.exchange_ticker) else str(r.ric),
                "start_date": _iso(r.date),
                "end_date": None,
                "source_vendor": "refinitiv",
                "upsert_date": now,
                "upsert_by": UPSERT_BY,
            }
            for r in joiners.itertuples(index=False)
        ]
        if rows:
            session.bulk_insert_mappings(db.IndexConstituents, rows)
            session.commit()
    opened = int(len(joiners)) if not diff.joiners.empty else 0
    summary = {"intervals_closed": closed, "intervals_opened": opened, "skipped_unresolved": skipped}
    log.info("membership applied for index_id=%s: %s", index_id, summary)
    return summary


# ---------------------------------------------------------------------------
# Holdings for the new dates
# ---------------------------------------------------------------------------


def upsert_holdings_window(session: Any, port_id: int, holdings: DataFrame) -> int:
    """Replace a portfolio's holdings on exactly the dates present in ``holdings`` (other dates untouched)."""
    if holdings.empty:
        return 0
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    rows = holdings.copy()
    rows["as_of_date"] = pd.to_datetime(rows["as_of_date"]).dt.strftime("%Y-%m-%d")
    rows["port_id"] = int(port_id)
    rows["upsert_date"] = now
    rows["upsert_by"] = UPSERT_BY
    dates = sorted(rows["as_of_date"].unique().tolist())
    session.query(db.PortfolioHoldings).filter(
        db.PortfolioHoldings.port_id == int(port_id), db.PortfolioHoldings.as_of_date.in_(dates)
    ).delete(synchronize_session=False)
    session.bulk_insert_mappings(
        db.PortfolioHoldings,
        rows[["as_of_date", "port_id", "security_id", "held_shares", "upsert_date", "upsert_by"]].to_dict(orient="records"),
    )
    session.commit()
    log.info("upserted %d holdings rows for port_id=%s on %d dates (%s..%s)", len(rows), port_id, len(dates), dates[0], dates[-1])
    return len(rows)


def extend_index_holdings(
    session: Any, engine: Any, port_id: int, index_id: int, start: Any, end: Any, held_shares: float = 1.0
) -> int:
    """Append daily index holdings for business days in ``[start, end]`` from the stored membership intervals."""
    members = db.read_index_constituents(session, engine, _iso(start), _iso(end))
    members = members[(members["index_id"] == index_id) & members["security_id"].notna()].copy()
    if members.empty:
        raise ValueError(f"No index_constituents rows for index_id={index_id}")
    members["start"] = pd.to_datetime(members["start_date"])
    members["end"] = pd.to_datetime(members["end_date"]).fillna(pd.Timestamp(end))
    dates = business_days(_iso(start), _iso(end))
    rows = []
    for r in members.itertuples(index=False):
        active = dates[(dates >= r.start) & (dates <= r.end)]
        if len(active):
            rows.append(DataFrame({"as_of_date": active, "security_id": int(r.security_id), "held_shares": held_shares}))
    if not rows:
        return 0
    frame = pd.concat(rows, ignore_index=True).drop_duplicates(["as_of_date", "security_id"])
    return upsert_holdings_window(session, port_id, frame)


def extend_constant_holdings(session: Any, port_id: int, shares_by_security: Mapping[int, float], start: Any, end: Any) -> int:
    """Append fixed-share holdings (ETF / index level / thesis book) for business days in ``[start, end]``."""
    dates = business_days(_iso(start), _iso(end))
    frame = DataFrame(
        [(d, int(sec), float(qty)) for d in dates for sec, qty in shares_by_security.items()],
        columns=["as_of_date", "security_id", "held_shares"],
    )
    return upsert_holdings_window(session, port_id, frame)


# ---------------------------------------------------------------------------
# Float-adjusted shares
# ---------------------------------------------------------------------------


def refresh_float_shares(session: Any, engine: Any, index_id: int, start: Any, end: Any, chunk_size: int = 20) -> int:
    """Pull float-adjusted shares for the window for every member active in it and MERGE them into ``security_fundamentals``."""
    from data_engineering.index_constituents.refinitiv import build_float_adjusted_shares

    constituents = active_constituents(session, engine, index_id, start, end)
    if constituents.empty:
        return 0
    shares = build_float_adjusted_shares(constituents, start=_iso(start), end=_iso(end), chunk_size=chunk_size)
    if shares.empty:
        return 0
    return int(db.write_security_fundamentals(shares, session))


def active_constituents(session: Any, engine: Any, index_id: int, start: Any, end: Any) -> DataFrame:
    """Members whose interval overlaps ``[start, end]``: ``[Constituent RIC, exchange_ticker, security_id]`` (RIC from the xref)."""
    members = db.read_index_constituents(session, engine, _iso(start), _iso(end))
    members = members[(members["index_id"] == index_id) & members["security_id"].notna()].copy()
    s, e = pd.Timestamp(start), pd.Timestamp(end)
    members["start"] = pd.to_datetime(members["start_date"])
    members["end"] = pd.to_datetime(members["end_date"]).fillna(pd.Timestamp.max)
    members = members[(members["start"] <= e) & (members["end"] >= s)]
    if members.empty:
        return DataFrame(columns=["Constituent RIC", "exchange_ticker", "security_id"])
    from data_engineering.refinitiv import qualify_tickers, strip_event_suffix

    xref = db.read_security_vendor_xref(session, engine, vendor="Refinitiv").dropna(subset=["vendor_ticker"])
    xref = xref.sort_values("is_primary", ascending=False).drop_duplicates("security_id").set_index("security_id")["vendor_ticker"]
    members["security_id"] = members["security_id"].astype(int)
    members["Constituent RIC"] = members["security_id"].map(xref).map(lambda r: strip_event_suffix(r) if isinstance(r, str) else r)
    out = members.dropna(subset=["Constituent RIC"])[["Constituent RIC", "exchange_ticker", "security_id"]].copy()
    # the shares endpoint needs exchange-qualified RICs (``AAPL.O``); bare tickers return sparse data
    qmap = qualify_tickers(out["Constituent RIC"].drop_duplicates().tolist())
    out["Constituent RIC"] = out["Constituent RIC"].map(lambda r: qmap.get(r, r))
    return out.drop_duplicates("security_id").reset_index(drop=True)


# ---------------------------------------------------------------------------
# Prices
# ---------------------------------------------------------------------------


def refresh_prices(
    universe: DataFrame,
    session: Any,
    engine: Any,
    start: Any,
    end: Any,
    *,
    vendor: str = "refinitiv",
    batch_size: int = 20,
    max_retries: int = 3,
    mop_up: bool = True,
    prune_portfolios: Sequence[str] = ("SP500", "SPY", "GSPC"),
    min_coverage: float = 0.5,
    **load_kwargs: Any,
) -> dict[str, Any]:
    """EOD prices for the window: batched load, mop-up of empty names, holiday pruning of holdings."""
    n_bdays = max(1, len(business_days(_iso(start), _iso(end))))
    summary: EodLoadSummary = load_eod_prices(
        universe, session, _iso(start), _iso(end), vendor=vendor, batch_size=batch_size, max_retries=max_retries, **load_kwargs
    )
    out: dict[str, Any] = {
        "window": (_iso(start), _iso(end)),
        "rows_written": summary.rows_written,
        "securities_loaded": summary.securities_loaded,
        "securities_requested": summary.securities_requested,
        "dropped_implausible_rows": summary.dropped_implausible_rows,
        "missing_after_load": list(summary.missing_security_ids),
    }
    if mop_up:
        # in a short window a name with fewer than half the business days priced is treated as broken and re-pulled alone
        mop = mop_up_missing_prices(
            universe,
            session,
            engine,
            _iso(start),
            _iso(end),
            vendor=vendor,
            min_days=max(1, n_bdays // 2),
            batch_size=1,
            **load_kwargs,
        )
        out["mop_up_rows"] = mop.rows_written
        out["still_missing"] = list(mop.missing_security_ids)
    if prune_portfolios:
        out["pruned_dates"] = prune_low_coverage_holdings(
            engine, list(prune_portfolios), _iso(start), _iso(end), min_coverage=min_coverage
        )
    return out


def priced_dates_frame(engine: Any, security_ids: Iterable[int], start: Any, end: Any) -> DataFrame:
    """``[security_id, as_of_date]`` rows present in ``market_data`` for the window."""
    import sqlalchemy as sa

    ids = [int(s) for s in security_ids]
    if not ids:
        return DataFrame(columns=["security_id", "as_of_date"])
    q = sa.text(
        "SELECT security_id, as_of_date FROM dbo.market_data "
        "WHERE as_of_date BETWEEN :s AND :e AND security_id IN :ids"
    ).bindparams(sa.bindparam("ids", expanding=True))
    out = pd.read_sql_query(q, engine, params={"s": _iso(start), "e": _iso(end), "ids": ids})
    out["as_of_date"] = pd.to_datetime(out["as_of_date"])
    out["security_id"] = out["security_id"].astype(int)
    return out


def price_gaps_from_frames(priced: DataFrame, security_ids: Iterable[int], min_coverage: float = 0.5) -> DataFrame:
    """Per-security missing trading days, with the trading calendar inferred from the data (pure function).

    A date counts as a trading day when at least ``min_coverage`` of the
    securities have a price on it, so exchange holidays are not reported as
    gaps. Returns ``[security_id, expected_days, priced_days, missing_days,
    missing_dates]`` sorted by ``missing_days`` descending (only names with gaps).
    """
    ids = [int(s) for s in security_ids]
    if priced.empty or not ids:
        return DataFrame(columns=["security_id", "expected_days", "priced_days", "missing_days", "missing_dates"])
    px = priced[priced["security_id"].isin(ids)].drop_duplicates(["security_id", "as_of_date"])
    per_date = px.groupby("as_of_date")["security_id"].nunique()
    calendar = per_date[per_date >= min_coverage * len(ids)].index.sort_values()
    if len(calendar) == 0:
        return DataFrame(columns=["security_id", "expected_days", "priced_days", "missing_days", "missing_dates"])
    have = px.groupby("security_id")["as_of_date"].apply(set)
    rows = []
    cal_set = set(calendar)
    for sec in ids:
        got = have.get(sec, set()) & cal_set
        missing = sorted(cal_set - got)
        if missing:
            rows.append(
                {
                    "security_id": sec,
                    "expected_days": len(cal_set),
                    "priced_days": len(got),
                    "missing_days": len(missing),
                    "missing_dates": ", ".join(d.strftime("%Y-%m-%d") for d in missing[:10]) + (" ..." if len(missing) > 10 else ""),
                }
            )
    out = DataFrame(rows, columns=["security_id", "expected_days", "priced_days", "missing_days", "missing_dates"])
    return out.sort_values(["missing_days", "security_id"], ascending=[False, True]).reset_index(drop=True)


def price_gaps(engine: Any, security_ids: Iterable[int], start: Any, end: Any, min_coverage: float = 0.5) -> DataFrame:
    """:func:`price_gaps_from_frames` on the database for the window."""
    ids = [int(s) for s in security_ids]
    return price_gaps_from_frames(priced_dates_frame(engine, ids, start, end), ids, min_coverage)


# ---------------------------------------------------------------------------
# Fundamentals
# ---------------------------------------------------------------------------


@dataclass
class FundamentalsDiff:
    """Incoming fundamentals rows classified against what the database already holds.

    Attributes:
        new_rows: cells (security, metric, period) not stored yet.
        restated_rows: stored cells whose value changed beyond tolerance.
        unchanged: count of identical cells.
        new_periods: ``[security_id, effective_date]`` fiscal periods with no
            stored row at all for that security - the "a new quarter has been
            published" signal.
        newly_covered: securities that had no stored history in the window
            but have incoming rows.
        no_incoming: securities in the universe for which the vendor returned nothing.
    """

    new_rows: DataFrame
    restated_rows: DataFrame
    unchanged: int
    new_periods: DataFrame
    newly_covered: list[int]
    no_incoming: list[int] = field(default_factory=list)

    @property
    def rows_to_write(self) -> DataFrame:
        """New plus restated rows (what the upsert needs)."""
        parts = [f for f in (self.new_rows, self.restated_rows) if not f.empty]
        return pd.concat(parts, ignore_index=True) if parts else self.new_rows.iloc[0:0]

    def summary(self) -> dict[str, Any]:
        """Counts for logging / display."""
        return {
            "new_cells": int(len(self.new_rows)),
            "restated_cells": int(len(self.restated_rows)),
            "unchanged_cells": int(self.unchanged),
            "new_periods": int(len(self.new_periods)),
            "securities_with_new_period": int(self.new_periods["security_id"].nunique()) if not self.new_periods.empty else 0,
            "newly_covered_securities": int(len(self.newly_covered)),
            "securities_without_vendor_rows": int(len(self.no_incoming)),
        }


def fundamentals_window(as_of: Optional[Any] = None, lookback_quarters: int = 2) -> tuple[str, str]:
    """``(from, to)`` covering the last ``lookback_quarters`` fiscal quarters up to ``as_of`` (default today)."""
    end = pd.Timestamp(as_of).normalize() if as_of is not None else _today()
    start = (end - pd.DateOffset(months=3 * int(lookback_quarters))).normalize()
    return _iso(start), _iso(end)


def latest_fundamental_periods(
    engine: Any,
    source_vendor: str = "refinitiv",
    security_ids: Optional[Iterable[int]] = None,
    metric_types: Optional[Sequence[str]] = None,
) -> Series:
    """``security_id -> newest effective_date`` stored for the ratio metrics (one aggregate query)."""
    import sqlalchemy as sa

    metrics = list(metric_types) if metric_types is not None else list(METRIC_COLUMNS)
    q = (
        "SELECT security_id, MAX(effective_date) AS last_period FROM dbo.security_fundamentals "
        "WHERE source_vendor = :v AND metric_type IN :m"
    )
    params: dict[str, Any] = {"v": source_vendor, "m": metrics}
    binds = [sa.bindparam("m", expanding=True)]
    ids = [int(s) for s in security_ids] if security_ids is not None else None
    if ids:
        q += " AND security_id IN :ids"
        params["ids"] = ids
        binds.append(sa.bindparam("ids", expanding=True))
    q += " GROUP BY security_id"
    out = pd.read_sql_query(sa.text(q).bindparams(*binds), engine, params=params)
    if out.empty:
        return Series(dtype="datetime64[ns]", name="last_period")
    out["last_period"] = pd.to_datetime(out["last_period"])
    return out.set_index("security_id")["last_period"].sort_index()


def read_fundamentals_window(
    engine: Any,
    from_date: Any,
    to_date: Any,
    source_vendor: str = "refinitiv",
    security_ids: Optional[Iterable[int]] = None,
    metric_types: Optional[Sequence[str]] = None,
) -> DataFrame:
    """Stored fundamentals rows with ``effective_date`` in the window (windowed SQL, not a full-table read)."""
    import sqlalchemy as sa

    metrics = list(metric_types) if metric_types is not None else list(METRIC_COLUMNS)
    q = (
        "SELECT security_id, metric_type, metric_value, source_vendor, effective_date, end_date FROM dbo.security_fundamentals "
        "WHERE source_vendor = :v AND metric_type IN :m AND effective_date BETWEEN :s AND :e"
    )
    params: dict[str, Any] = {"v": source_vendor, "m": metrics, "s": _iso(from_date), "e": _iso(to_date)}
    binds = [sa.bindparam("m", expanding=True)]
    ids = [int(s) for s in security_ids] if security_ids is not None else None
    if ids:
        q += " AND security_id IN :ids"
        params["ids"] = ids
        binds.append(sa.bindparam("ids", expanding=True))
    out = pd.read_sql_query(sa.text(q).bindparams(*binds), engine, params=params)
    if not out.empty:
        out["security_id"] = out["security_id"].astype(int)
        out["effective_date"] = pd.to_datetime(out["effective_date"])
    return out


def _normalise_fund_rows(rows: DataFrame) -> DataFrame:
    out = rows.copy()
    out["security_id"] = out["security_id"].astype(int)
    out["metric_type"] = out["metric_type"].astype(str)
    out["effective_date"] = pd.to_datetime(out["effective_date"]).dt.normalize()
    out["metric_value"] = pd.to_numeric(out["metric_value"], errors="coerce")
    return out.dropna(subset=["metric_value"]).drop_duplicates(FUNDAMENTAL_KEYS, keep="last")


def diff_fundamentals(
    stored: DataFrame,
    incoming: DataFrame,
    universe_ids: Optional[Iterable[int]] = None,
    stored_any: Optional[Iterable[int]] = None,
    rel_tol: float = 1e-6,
    abs_tol: float = 1e-9,
) -> FundamentalsDiff:
    """Classify ``incoming`` fundamentals rows against ``stored`` rows (pure function).

    Both frames carry ``security_id, metric_type, metric_value, effective_date``
    (``source_vendor`` is assumed identical). ``universe_ids`` lets the diff
    report securities the vendor returned nothing for; ``stored_any`` is the set
    of securities that have *any* stored history (default: those in ``stored``),
    used for ``newly_covered``.
    """
    cols = FUNDAMENTAL_KEYS + ["metric_value"]
    st = _normalise_fund_rows(stored[cols]) if not stored.empty else DataFrame(columns=cols)
    inc_cols = incoming.columns if len(incoming.columns) else cols
    inc = _normalise_fund_rows(incoming) if not incoming.empty else DataFrame(columns=inc_cols)
    if inc.empty:
        empty = inc.iloc[0:0]
        nothing = sorted(set(int(s) for s in (universe_ids or [])))
        return FundamentalsDiff(empty, empty, 0, DataFrame(columns=["security_id", "effective_date"]), [], nothing)
    merged = inc.merge(st[cols].rename(columns={"metric_value": "_stored"}), on=FUNDAMENTAL_KEYS, how="left", indicator=True)
    is_new = merged["_merge"] == "left_only"
    incoming_vals = merged["metric_value"].to_numpy(dtype=float)
    stored_vals = merged["_stored"].to_numpy(dtype=float)
    same = np.isclose(incoming_vals, stored_vals, rtol=rel_tol, atol=abs_tol, equal_nan=True)
    is_restated = (~is_new) & ~same
    keep_cols = [c for c in inc.columns if c in merged.columns]
    new_rows = merged.loc[is_new, keep_cols].reset_index(drop=True)
    restated = merged.loc[is_restated, keep_cols + ["_stored"]].rename(columns={"_stored": "previous_value"}).reset_index(drop=True)
    unchanged = int(((~is_new) & same).sum())

    period_cols = ["security_id", "effective_date"]
    stored_periods = st[period_cols].drop_duplicates() if not st.empty else DataFrame(columns=period_cols)
    inc_periods = inc[period_cols].drop_duplicates()
    new_periods = inc_periods.merge(stored_periods, how="left", indicator=True)
    new_periods = new_periods[new_periods["_merge"] == "left_only"].drop(columns="_merge")
    new_periods = new_periods.sort_values(period_cols).reset_index(drop=True)

    covered_before = set(int(s) for s in (stored_any if stored_any is not None else st["security_id"].unique()))
    newly_covered = sorted(set(int(s) for s in inc["security_id"].unique()) - covered_before)
    no_incoming = sorted(set(int(s) for s in (universe_ids or [])) - set(int(s) for s in inc["security_id"].unique()))
    return FundamentalsDiff(new_rows, restated, unchanged, new_periods, newly_covered, no_incoming)


def pull_fundamentals_history(
    universe: DataFrame,
    session: Any,
    engine: Any,
    from_date: Any,
    to_date: Any,
    *,
    provider_name: str = "refinitiv",
    frequency: str = "Q",
    source_vendor: str = "refinitiv",
    include_growth: bool = True,
    retry_individually: bool = True,
) -> DataFrame:
    """Pull ratio history for ``universe`` in the window as long ``security_fundamentals`` rows (nothing written).

    Names the bulk pull returned nothing for are retried one at a time (a
    single-RIC request rarely hits the gateway timeout that drops a chunk).
    """
    symbols = universe[["security_id", "symbol"]].copy()
    provider = get_fundamentals_provider(
        provider_name,
        orm_session=session,
        orm_engine=engine,
        frequency=frequency,
        start_date=_iso(from_date),
        include_growth=include_growth,
    )

    def _pull(sym: DataFrame) -> DataFrame:
        snapshot, history = provider.get_panel_history(sym, _iso(to_date), frequency=frequency, start_date=_iso(from_date))
        if history is not None and not history.empty:
            rows = history_to_long(history, source_vendor)
        elif snapshot is not None and not snapshot.dropna(how="all").empty:
            rows = panel_to_long(snapshot.dropna(how="all"), _iso(to_date), source_vendor)
        else:
            return DataFrame()
        rows["effective_date"] = pd.to_datetime(rows["effective_date"])
        return rows[(rows["effective_date"] >= pd.Timestamp(from_date)) & (rows["effective_date"] <= pd.Timestamp(to_date))]

    rows = _pull(symbols)
    got = set(int(s) for s in rows["security_id"].unique()) if not rows.empty else set()
    missed = [int(s) for s in symbols["security_id"] if int(s) not in got]
    log.info("fundamentals pull: %d/%d securities returned rows in %s..%s", len(got), len(symbols), _iso(from_date), _iso(to_date))
    if retry_individually and missed:
        extra = []
        for i, sec_id in enumerate(missed, start=1):
            try:
                one = _pull(symbols[symbols["security_id"] == sec_id])
            except Exception as exc:  # noqa: BLE001 - keep going through the list
                log.warning("[%d/%d] security %s retry failed: %s", i, len(missed), sec_id, exc)
                continue
            if not one.empty:
                extra.append(one)
        if extra:
            rows = pd.concat([rows] + extra, ignore_index=True) if not rows.empty else pd.concat(extra, ignore_index=True)
            log.info("fundamentals retry recovered %d of %d securities", len(extra), len(missed))
    return rows.reset_index(drop=True) if not rows.empty else rows


def load_fundamentals_incremental(
    universe: DataFrame,
    session: Any,
    engine: Any,
    as_of: Optional[Any] = None,
    lookback_quarters: int = 2,
    *,
    provider_name: str = "refinitiv",
    frequency: str = "Q",
    source_vendor: str = "refinitiv",
    include_growth: bool = True,
    dry_run: bool = False,
    retry_individually: bool = True,
) -> dict[str, Any]:
    """Pull the recent fiscal quarters, diff them against the database and upsert only what changed.

    Returns ``{"window", "diff": FundamentalsDiff, "rows_written", "latest_period_end", "dry_run"}``.
    With ``dry_run=True`` nothing is written; the diff tells you what *would* be.
    """
    from_date, to_date = fundamentals_window(as_of, lookback_quarters)
    ids = [int(s) for s in universe["security_id"]]
    stored = read_fundamentals_window(engine, from_date, to_date, source_vendor, ids)
    stored_any = latest_fundamental_periods(engine, source_vendor, ids)
    incoming = pull_fundamentals_history(
        universe,
        session,
        engine,
        from_date,
        to_date,
        provider_name=provider_name,
        frequency=frequency,
        source_vendor=source_vendor,
        include_growth=include_growth,
        retry_individually=retry_individually,
    )
    diff = diff_fundamentals(stored, incoming, universe_ids=ids, stored_any=stored_any.index.tolist())
    written = 0
    to_write = diff.rows_to_write
    if not dry_run and not to_write.empty:
        payload = to_write[["security_id", "metric_type", "metric_value", "source_vendor", "effective_date"]].copy()
        payload["end_date"] = None
        written = int(db.write_security_fundamentals(payload, session))
    if not incoming.empty:
        latest = pd.to_datetime(incoming["effective_date"]).max()
    else:
        latest = stored_any.max() if not stored_any.empty else None
    log.info("fundamentals incremental %s..%s: %s | written=%d dry_run=%s", from_date, to_date, diff.summary(), written, dry_run)
    return {"window": (from_date, to_date), "diff": diff, "rows_written": written, "latest_period_end": latest, "dry_run": dry_run}


__all__ = [
    "price_window",
    "latest_price_date",
    "latest_price_dates",
    "resolve_price_window",
    "MembershipDiff",
    "stored_open_members",
    "current_index_members",
    "recent_constituent_events",
    "resolve_rics_to_security_ids",
    "diff_membership",
    "check_index_membership",
    "apply_membership_diff",
    "upsert_holdings_window",
    "extend_index_holdings",
    "extend_constant_holdings",
    "refresh_float_shares",
    "active_constituents",
    "refresh_prices",
    "priced_dates_frame",
    "price_gaps_from_frames",
    "price_gaps",
    "FundamentalsDiff",
    "fundamentals_window",
    "latest_fundamental_periods",
    "read_fundamentals_window",
    "diff_fundamentals",
    "pull_fundamentals_history",
    "load_fundamentals_incremental",
]
