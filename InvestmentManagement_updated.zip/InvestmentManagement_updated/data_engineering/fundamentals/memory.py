"""In-memory point-in-time fundamentals provider (tests, demos, CSV-backed research)."""

from __future__ import annotations

from typing import Optional, Sequence

import pandas as pd
from pandas import DataFrame

from .base import FundamentalsProvider
from .ratios import METRIC_COLUMNS, RATIO_COLUMNS, empty_panel


class InMemoryFundamentalsProvider(FundamentalsProvider):
    """Serve point-in-time panels from a long history frame already in memory.

    Args:
        history: ``[security_id, effective_date, *RATIO_COLUMNS]`` with one row
            per security per fiscal period (the same shape the Refinitiv
            provider's quarterly history and the database provider's
            ``get_panel_history`` return).
        availability_lag_days: publication lag added to ``effective_date``
            before a row becomes visible (see ``StaticFundamentalsProvider``).
        metric_columns: panel columns served (default ``RATIO_COLUMNS``; pass
            ``METRIC_COLUMNS`` when the history carries the growth metrics).
    """

    name = "memory"

    def __init__(self, history: DataFrame, availability_lag_days: int = 0, metric_columns: Optional[Sequence[str]] = None):
        """Index the history by availability date."""
        cols = list(metric_columns) if metric_columns is not None else list(RATIO_COLUMNS)
        unknown = [c for c in cols if c not in METRIC_COLUMNS]
        if unknown:
            raise ValueError(f"unknown metric columns {unknown}; known: {METRIC_COLUMNS}")
        self.metric_columns: list[str] = cols
        hist = history.copy()
        for c in cols:  # a history without a metric still yields a (NaN) column of that name
            if c not in hist.columns:
                hist[c] = float("nan")
        hist["security_id"] = hist["security_id"].astype(int)
        hist["effective_date"] = pd.to_datetime(hist["effective_date"])
        hist["available_date"] = hist["effective_date"] + pd.Timedelta(days=int(availability_lag_days))
        self._history = hist.sort_values(["available_date", "security_id"]).reset_index(drop=True)

    def get_panel(self, symbols: DataFrame, as_of_date: str) -> DataFrame:
        """Latest row per security available on/before ``as_of_date``."""
        sec_ids = [int(s) for s in symbols["security_id"]]
        visible = self._history[
            (self._history["available_date"] <= pd.Timestamp(as_of_date)) & self._history["security_id"].isin(sec_ids)
        ]
        if visible.empty:
            return empty_panel(sec_ids, self.metric_columns)
        latest = visible.groupby("security_id").tail(1).set_index("security_id")
        return latest.reindex(index=pd.Index(sec_ids, name="security_id"), columns=self.metric_columns).astype(float)

    def get_panel_history(
        self, symbols: DataFrame, as_of_date: str, frequency: str = "FY", start_date: Optional[str] = None
    ) -> tuple[DataFrame, Optional[DataFrame]]:
        """``(latest_panel, history rows with effective_date in the window)``."""
        sec_ids = [int(s) for s in symbols["security_id"]]
        hist = self._history[
            self._history["security_id"].isin(sec_ids) & (self._history["effective_date"] <= pd.Timestamp(as_of_date))
        ]
        if start_date:
            hist = hist[hist["effective_date"] >= pd.Timestamp(start_date)]
        return self.get_panel(symbols, as_of_date), (
            hist[["security_id", "effective_date"] + self.metric_columns].reset_index(drop=True) if not hist.empty else None
        )
