"""The canonical fundamental-ratio contract and the formulas behind it.

Every fundamentals provider - whatever vendor it talks to - emits a *wide*
panel indexed by ``security_id`` whose columns are exactly ``RATIO_COLUMNS``.
The ML value factor is trained on that column set, so the names and order are
part of the model contract: changing them means retraining.

Vendors differ only in *which raw items* they can supply. They map their
fields onto the internal item names in :data:`RAW_ITEMS` and call
:func:`compute_ratios`; the formulas live in one place.
"""

from __future__ import annotations

from typing import Iterable, Optional, Sequence

import numpy as np
import pandas as pd
from pandas import DataFrame

#: The 18 fundamental ratios the ML models consume, in the exact order used when
#: the pipelines were trained. DO NOT reorder or rename without retraining.
RATIO_COLUMNS: list[str] = [
    "EV/EBIT",
    "Op. In./(NWC+FA)",
    "P/E",
    "P/B",
    "P/S",
    "Op. In./Interest Expense",
    "Working Capital Ratio",
    "RoE",
    "ROCE",
    "Debt/Equity",
    "Debt Ratio",
    "Cash Ratio",
    "Asset Turnover",
    "Gross Profit Margin",
    "(CA-CL)/TA",
    "RE/TA",
    "EBIT/TA",
    "Book Equity/TL",
]

#: Internal names for the raw accounting items a vendor may supply. Missing
#: items are allowed; the ratios that need them come back as NaN.
RAW_ITEMS: list[str] = [
    "price",
    "mkt_cap",
    "shares",
    "ent_val",
    "ebit",
    "operating_income",
    "revenue",
    "gross_profit",
    "net_income",
    "interest_exp",
    "total_assets",
    "total_liab",
    "book_equity",
    "total_debt",
    "current_assets",
    "current_liab",
    "cash",
    "fixed_assets",
    "retained_earnings",
]

#: Ratios where a higher value means *cheaper* / better for a long-only value
#: screen. Used by :class:`analytics.factors.value.ValueFactor`.
VALUE_MULTIPLES_LOWER_IS_BETTER = ["EV/EBIT", "P/E", "P/B", "P/S"]

#: Growth / trend metrics derived from the *time series* of raw items (see
#: :func:`compute_growth_ratios`). They are stored in ``security_fundamentals``
#: next to the 18 ratios but are NOT part of the ML feature contract: the
#: persisted models keep reading exactly ``RATIO_COLUMNS`` by name, so adding
#: or extending this list never requires retraining.
GROWTH_COLUMNS: list[str] = [
    "Revenue Growth",  # TTM revenue / TTM revenue one year earlier - 1
    "Earnings Growth",  # TTM net income growth (both TTM values must be > 0)
    "EBIT Growth",  # TTM EBIT growth (both TTM values must be > 0)
    "Gross Margin Change",  # TTM gross margin - TTM gross margin one year earlier
    "Asset Growth",  # total assets / total assets one year earlier - 1 (a negative predictor)
    "Share Issuance",  # shares outstanding / shares one year earlier - 1 (buybacks < 0)
]

#: Everything a provider may emit and the database stores: the ML ratio
#: contract plus the growth extension. Providers return ``RATIO_COLUMNS`` by
#: default and the wider set when asked (``metric_columns=METRIC_COLUMNS``).
METRIC_COLUMNS: list[str] = RATIO_COLUMNS + GROWTH_COLUMNS

#: Quarters of raw history a growth metric needs before its first value exists
#: (four quarters for the trailing-twelve-month sum, four more for the
#: year-earlier comparison).
GROWTH_HISTORY_QUARTERS = 8


def empty_panel(security_ids: Iterable[int], columns: Optional[Sequence[str]] = None) -> DataFrame:
    """Return an all-NaN ratio panel indexed by ``security_id`` (default columns: ``RATIO_COLUMNS``)."""
    idx = pd.Index(list(security_ids), name="security_id")
    return DataFrame(index=idx, columns=list(columns) if columns is not None else RATIO_COLUMNS, dtype=float)


def _item(items: DataFrame, name: str) -> pd.Series:
    """Fetch one raw item as float64, NaN if the vendor did not supply it.

    Vendors can return text (``"NM"``, ``"-"``) for some fundamentals and pandas
    may hand back nullable dtypes; both are coerced to plain float so the ratio
    arithmetic below never raises on mixed dtypes.
    """
    if name not in items.columns:
        return pd.Series(np.nan, index=items.index, dtype=float)
    return pd.to_numeric(items[name], errors="coerce").astype(float)


def _safe_denominator(s: pd.Series) -> pd.Series:
    """Turn zero denominators into NaN so ratios are NaN rather than +/-inf."""
    return s.replace(0, np.nan)


def compute_ratios(items: DataFrame) -> DataFrame:
    """Compute the 18 ``RATIO_COLUMNS`` from a frame of raw accounting items.

    Args:
        items: any index (RIC, security_id, or (security_id, period_end)); columns
            drawn from :data:`RAW_ITEMS`. Unknown columns are ignored.

    Derivations applied when a direct item is missing (all standard identities):
        * ``mkt_cap``     = price x shares
        * ``book_equity`` = total_assets - total_liabilities
        * ``total_liab``  = total_assets - book_equity
        * ``ent_val``     = mkt_cap + total_debt (equity value + debt proxy)

    Returns:
        DataFrame with the same index as ``items`` and columns = ``RATIO_COLUMNS``
        (float64). Ratios whose components are missing are NaN, never 0.
    """
    price = _item(items, "price")
    shares = _item(items, "shares")
    mkt_cap = _item(items, "mkt_cap")
    mkt_cap = mkt_cap.where(mkt_cap.notna(), price * shares)

    ebit = _item(items, "ebit")
    operating_income = _item(items, "operating_income")
    revenue = _item(items, "revenue")
    gross_profit = _item(items, "gross_profit")
    net_income = _item(items, "net_income")
    interest_exp = _item(items, "interest_exp")
    total_assets = _item(items, "total_assets")
    total_debt = _item(items, "total_debt")
    current_assets = _item(items, "current_assets")
    current_liab = _item(items, "current_liab")
    cash = _item(items, "cash")
    fixed_assets = _item(items, "fixed_assets")
    retained_earnings = _item(items, "retained_earnings")

    total_liab = _item(items, "total_liab")
    book_equity = _item(items, "book_equity")
    book_equity = book_equity.where(book_equity.notna(), total_assets - total_liab)
    total_liab = total_liab.where(total_liab.notna(), total_assets - book_equity)

    ent_val = _item(items, "ent_val")
    ent_val = ent_val.where(ent_val.notna(), mkt_cap + total_debt)

    nwc = current_assets - current_liab

    out = DataFrame(index=items.index, columns=RATIO_COLUMNS, dtype=float)
    out["EV/EBIT"] = ent_val / _safe_denominator(ebit)
    out["Op. In./(NWC+FA)"] = operating_income / _safe_denominator(nwc + fixed_assets)
    out["P/E"] = mkt_cap / _safe_denominator(net_income)
    out["P/B"] = mkt_cap / _safe_denominator(book_equity)
    out["P/S"] = mkt_cap / _safe_denominator(revenue)
    out["Op. In./Interest Expense"] = operating_income / _safe_denominator(interest_exp.abs())
    out["Working Capital Ratio"] = current_assets / _safe_denominator(current_liab)
    out["RoE"] = net_income / _safe_denominator(book_equity)
    out["ROCE"] = ebit / _safe_denominator(book_equity + total_debt)
    out["Debt/Equity"] = total_debt / _safe_denominator(book_equity)
    out["Debt Ratio"] = total_debt / _safe_denominator(total_assets)
    out["Cash Ratio"] = cash / _safe_denominator(current_liab)
    out["Asset Turnover"] = revenue / _safe_denominator(total_assets)
    out["Gross Profit Margin"] = gross_profit / _safe_denominator(revenue)
    out["(CA-CL)/TA"] = nwc / _safe_denominator(total_assets)
    out["RE/TA"] = retained_earnings / _safe_denominator(total_assets)
    out["EBIT/TA"] = ebit / _safe_denominator(total_assets)
    out["Book Equity/TL"] = book_equity / _safe_denominator(total_liab)
    return out.astype("float64")


# ---------------------------------------------------------------------------
# Growth metrics (need the time series of one security's raw items)
# ---------------------------------------------------------------------------


def _ttm(series: pd.Series) -> pd.Series:
    """Trailing-twelve-month sum of a quarterly flow (NaN until four quarters exist)."""
    return series.rolling(4, min_periods=4).sum()


def _positive_growth(current: pd.Series, previous: pd.Series) -> pd.Series:
    """``current / previous - 1`` only where both are strictly positive (else NaN)."""
    ok = (current > 0) & (previous > 0)
    return (current / previous - 1.0).where(ok)


def compute_growth_ratios(items: DataFrame, periods_per_year: int = 4) -> DataFrame:
    """Compute :data:`GROWTH_COLUMNS` for ONE security from its quarterly raw-item history.

    Args:
        items: raw items for a single security, indexed by fiscal period end
            (``DatetimeIndex``), columns drawn from :data:`RAW_ITEMS`
            (``revenue``, ``net_income``, ``ebit``, ``gross_profit``,
            ``total_assets``, ``shares``). Rows may be unsorted and quarters
            may be missing.
        periods_per_year: fiscal periods per year (4 = quarterly).

    The series is snapped onto the security's *own* quarterly grid
    (``PeriodIndex``) so that "one year earlier" always means four periods
    back; a missing quarter yields NaN rather than a silently misaligned
    comparison. Flow items (revenue, net income, EBIT, gross profit) are
    summed over the trailing four quarters before comparing, which removes
    seasonality; stock items (assets, shares) are compared point to point.

    Returns:
        DataFrame indexed exactly like ``items`` (same period-end dates, same
        order) with columns = :data:`GROWTH_COLUMNS`. NaN where undefined.
    """
    out = DataFrame(index=items.index, columns=GROWTH_COLUMNS, dtype=float)
    if items.empty:
        return out
    idx = pd.to_datetime(items.index)
    ordered = items.copy()
    ordered.index = idx
    ordered = ordered.sort_index()
    ordered = ordered[~ordered.index.duplicated(keep="last")]

    freq = {4: "Q", 1: "Y", 12: "M"}.get(periods_per_year, "Q")
    periods = ordered.index.to_period(freq)
    grid = ordered.copy()
    grid.index = periods
    grid = grid[~grid.index.duplicated(keep="last")]
    full = pd.period_range(grid.index.min(), grid.index.max(), freq=freq)
    grid = grid.reindex(full)

    revenue, net_income, ebit = _item(grid, "revenue"), _item(grid, "net_income"), _item(grid, "ebit")
    gross_profit, total_assets, shares = _item(grid, "gross_profit"), _item(grid, "total_assets"), _item(grid, "shares")
    n = periods_per_year

    ttm_rev, ttm_ni, ttm_ebit, ttm_gp = _ttm(revenue), _ttm(net_income), _ttm(ebit), _ttm(gross_profit)
    g = DataFrame(index=grid.index, columns=GROWTH_COLUMNS, dtype=float)
    g["Revenue Growth"] = _positive_growth(ttm_rev, ttm_rev.shift(n))
    g["Earnings Growth"] = _positive_growth(ttm_ni, ttm_ni.shift(n))
    g["EBIT Growth"] = _positive_growth(ttm_ebit, ttm_ebit.shift(n))
    margin = ttm_gp / _safe_denominator(ttm_rev)
    g["Gross Margin Change"] = margin - margin.shift(n)
    g["Asset Growth"] = _positive_growth(total_assets, total_assets.shift(n))
    g["Share Issuance"] = _positive_growth(shares, shares.shift(n))

    # Map back from the period grid onto the original (de-duplicated) period-end dates.
    back = g.loc[periods]
    back.index = ordered.index
    out.loc[:, :] = back.reindex(idx).to_numpy()
    return out.astype("float64")


def compute_ratios_with_growth(items: DataFrame, periods_per_year: int = 4) -> DataFrame:
    """``compute_ratios`` + ``compute_growth_ratios`` for ONE security's quarterly history.

    Convenience for providers that pull per-security time series: returns the
    full :data:`METRIC_COLUMNS` set indexed by fiscal period end.
    """
    ratios = compute_ratios(items)
    growth = compute_growth_ratios(items, periods_per_year=periods_per_year)
    return pd.concat([ratios, growth], axis=1)[METRIC_COLUMNS]
