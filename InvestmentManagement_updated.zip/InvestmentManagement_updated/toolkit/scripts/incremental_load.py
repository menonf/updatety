"""Daily / monthly refresh of reference data, prices and fundamentals (the headless twin of notebooks 01A and 03A).

Schedule it (Windows Task Scheduler / cron) after the US close once EOD prices
are published, or run it by hand after a long gap - the window is derived from
the last loaded date, so the same command works for both:

    python toolkit/scripts/incremental_load.py                       # prices + membership + holdings + float shares
    python toolkit/scripts/incremental_load.py --fundamentals        # ... and the last two fiscal quarters of ratios
    python toolkit/scripts/incremental_load.py --dry-run             # report what would change, write nothing
    python toolkit/scripts/incremental_load.py --as-of 2026-09-30 --fundamentals --lookback-quarters 3

Exit code is 0 when everything loaded, 2 when prices or fundamentals are still
missing for some names (details in the log), 1 on an error. Requires LSEG
Workspace running locally and the SQL Server credentials in the keyring.
"""

from __future__ import annotations

import argparse
import logging
import os
import sys

import pandas as pd

from analytics.factors import DEFAULT_ENSEMBLE, MODELS_DIR
from analytics.factors.ml_training import retrain_recommended
from data_engineering.database import database
from data_engineering.loaders import (
    apply_membership_diff,
    build_backtest_universe,
    check_index_membership,
    extend_constant_holdings,
    extend_index_holdings,
    get_or_create_portfolio,
    load_fundamentals_incremental,
    price_gaps,
    refresh_float_shares,
    refresh_prices,
    resolve_price_window,
    resolve_security_ids_by_ric,
)
from data_engineering.loaders.portfolios import portfolio_member_ids
from data_engineering.refinitiv import ensure_session

log = logging.getLogger("incremental_load")

INDEX_RIC, INDEX_ID = ".SPX", 2
ETF_RIC, INDEX_LEVEL_RIC = "SPY.P", ".SPX"
MAG8 = {"MSFT": 5, "GOOGL": 4, "AVGO": 3, "META": 2, "NVDA": 1, "TSLA": 1, "AMZN": 1, "AAPL": 1}
EXPORT_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "files", "reference")


def refresh_reference_and_prices(session, engine, as_of: str | None, buffer_days: int, dry_run: bool, vendor: str) -> dict:
    """Membership diff -> apply -> holdings for the new dates -> float shares -> prices -> gap report."""
    start, end = resolve_price_window(engine, as_of=as_of, buffer_days=buffer_days)
    log.info("price window %s -> %s", start, end)

    diff = check_index_membership(INDEX_RIC, INDEX_ID, session, engine, as_of=end)
    log.info("membership: %s", diff.summary())
    if not diff.is_empty:
        os.makedirs(EXPORT_DIR, exist_ok=True)
        path = os.path.join(EXPORT_DIR, f"membership_changes_{INDEX_RIC.strip('.').lower()}_{end}.csv")
        diff.change_log().to_csv(path, index=False)
        log.info("change log written to %s", path)
        if not dry_run:
            log.info("applied: %s", apply_membership_diff(diff, INDEX_ID, session, engine))
    if dry_run:
        return {"window": (start, end), "membership": diff.summary(), "dry_run": True}

    port_ids = {
        "SP500": get_or_create_portfolio(session, "SP500", "S&P 500 Reconstructed", "Benchmark"),
        "SPY": get_or_create_portfolio(session, "SPY", "S&P 500 ETF", "Portfolio"),
        "GSPC": get_or_create_portfolio(session, "GSPC", "S&P 500 Price Index", "Portfolio"),
        "MAG8": get_or_create_portfolio(session, "MAG8", "Backtest Mag 8", "Portfolio"),
    }
    ids = resolve_security_ids_by_ric(session, engine, [ETF_RIC, INDEX_LEVEL_RIC] + list(MAG8))
    n_rows = extend_index_holdings(session, engine, port_ids["SP500"], INDEX_ID, start, end)
    n_rows += extend_constant_holdings(session, port_ids["SPY"], {ids[ETF_RIC]: 1.0}, start, end)
    n_rows += extend_constant_holdings(session, port_ids["GSPC"], {ids[INDEX_LEVEL_RIC]: 1.0}, start, end)
    mag8 = {ids[t]: q for t, q in MAG8.items() if t in ids}
    if mag8:
        n_rows += extend_constant_holdings(session, port_ids["MAG8"], mag8, start, end)
    log.info("holdings rows upserted: %d", n_rows)

    n_shares = refresh_float_shares(session, engine, INDEX_ID, start, end)
    log.info("float-adjusted share rows merged: %d", n_shares)

    universe = build_backtest_universe(
        session, engine, INDEX_ID, extra_rics=(ETF_RIC, INDEX_LEVEL_RIC), extra_portfolios=("MAG8",), start_date=start, end_date=end
    )
    prices = refresh_prices(universe, session, engine, start, end, vendor=vendor)
    log.info("prices: %s", {k: v for k, v in prices.items() if k not in ("missing_after_load",)})
    gaps = price_gaps(engine, portfolio_member_ids(engine, "SP500"), start, end)
    if not gaps.empty:
        log.warning("%d securities have price gaps in the window (top: %s)", len(gaps), gaps.head(10).to_dict("records"))
    return {"window": (start, end), "membership": diff.summary(), "holdings_rows": n_rows, "share_rows": n_shares, "prices": prices, "gaps": int(len(gaps))}


def refresh_fundamentals(session, engine, as_of: str | None, lookback_quarters: int, dry_run: bool, universe_name: str, lag_days: int) -> dict:
    """Pull the recent quarters, diff, upsert what changed and say whether the ML models need a refit."""
    members = portfolio_member_ids(engine, universe_name)
    master = database.read_security_master(session, engine)
    universe = master[master["security_id"].isin(members)][["security_id", "name"]].rename(columns={"name": "symbol"}).drop_duplicates("security_id")
    result = load_fundamentals_incremental(universe, session, engine, as_of=as_of, lookback_quarters=lookback_quarters, dry_run=dry_run)
    diff = result["diff"]
    log.info("fundamentals %s: %s | rows written %d", result["window"], diff.summary(), result["rows_written"])
    if not diff.new_periods.empty:
        os.makedirs(EXPORT_DIR, exist_ok=True)
        path = os.path.join(EXPORT_DIR, f"new_fundamental_periods_{universe_name.lower()}_{result['window'][1]}.csv")
        diff.new_periods.to_csv(path, index=False)
        log.info("new fiscal periods written to %s", path)
    verdict = retrain_recommended(os.path.join(MODELS_DIR, universe_name.lower()), result["latest_period_end"], lag_days, as_of=as_of)
    log.info("ML models: %s", verdict["reason"])
    return {"window": result["window"], "diff": diff.summary(), "rows_written": result["rows_written"], "retrain": verdict}


def main(argv: list[str] | None = None) -> int:
    """Command-line entry point."""
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--as-of", default=None, help="window end (default today)")
    parser.add_argument("--buffer-days", type=int, default=3, help="business days before the last loaded date to re-pull")
    parser.add_argument("--vendor", default="refinitiv")
    parser.add_argument("--fundamentals", action="store_true", help="also refresh the last --lookback-quarters of ratios")
    parser.add_argument("--lookback-quarters", type=int, default=2)
    parser.add_argument("--universe", default="SP500", help="portfolio whose members get fundamentals")
    parser.add_argument("--lag-days", type=int, default=45, help="publication lag used for the retrain check")
    parser.add_argument("--skip-prices", action="store_true", help="only run the fundamentals refresh")
    parser.add_argument("--dry-run", action="store_true", help="report what would change; write nothing")
    args = parser.parse_args(argv)

    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    ensure_session()
    engine, connection, _conn_str, session = database.get_db_connection()
    status = 0
    try:
        if not args.skip_prices:
            out = refresh_reference_and_prices(session, engine, args.as_of, args.buffer_days, args.dry_run, args.vendor)
            if not args.dry_run and (out["prices"].get("still_missing") or out.get("gaps")):
                status = 2
        if args.fundamentals or args.skip_prices:
            out = refresh_fundamentals(session, engine, args.as_of, args.lookback_quarters, args.dry_run, args.universe, args.lag_days)
            if out["diff"]["securities_without_vendor_rows"]:
                status = max(status, 2)
            if out["retrain"]["recommended"]:
                log.warning("RETRAIN RECOMMENDED: %s (models %s)", out["retrain"]["reason"], DEFAULT_ENSEMBLE)
    except Exception:  # noqa: BLE001 - log and signal failure to the scheduler
        log.exception("incremental load failed")
        status = 1
    finally:
        session.close()
        connection.close()
    print(f"incremental load finished with status {status} at {pd.Timestamp.now():%Y-%m-%d %H:%M}")
    return status


if __name__ == "__main__":
    sys.exit(main())
