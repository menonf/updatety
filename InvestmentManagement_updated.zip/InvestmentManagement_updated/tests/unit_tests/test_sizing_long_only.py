"""Position sizing schemes, holding buffer, long-only construction and the strategy config (pure pandas)."""

import json
import os
import tempfile

import numpy as np
import pandas as pd
import pytest

from analytics.backtest import prices_to_returns, run_backtest, summary_table, turnover
from analytics.factors import MomentumFactor, RatioSpec
from analytics.factors.transforms import sample_on
from analytics.portfolio import (
    active_weights,
    buffered_weights,
    cap_sector_weights,
    clip_active_weights,
    long_only_weights,
    membership_matrix,
    position_weights,
    quantile_weights,
    rebalance_dates,
    sector_weights,
    tilt_weights,
    trailing_volatility,
)
from analytics.strategy import MOMENTUM_ML_VALUE_LONG_ONLY, SignalSpec, StrategyConfig, blend, build_weights, compute_signals
from data_engineering.fundamentals import METRIC_COLUMNS, InMemoryFundamentalsProvider
from tests.unit_tests.synthetic import synthetic_fundamentals_history, synthetic_prices


def _signal(n: int = 60, days: int = 500):
    prices = synthetic_prices(n_securities=n, n_days=days, seed=3)
    return prices, MomentumFactor(126, 21).compute(prices)


def test_position_weight_schemes_keep_leg_sums_and_selection() -> None:
    prices, sig = _signal()
    live = sig.notna().any(axis=1)
    base = quantile_weights(sig, 0.1)
    for scheme in ("equal", "score", "rank"):
        w = position_weights(sig, 0.1, scheme=scheme)
        assert np.allclose(w[live].clip(lower=0).sum(axis=1), 1.0)
        assert np.allclose(w[live].clip(upper=0).sum(axis=1), -1.0)
        assert ((w != 0) == (base != 0)).all().all()  # same names, different sizes
    w = position_weights(sig, 0.1, scheme="score")
    last = w.iloc[-1]
    longs = last[last > 0].sort_values()
    assert (sig.iloc[-1][longs.index].diff().dropna() >= 0).all()  # bigger weight <-> higher score
    with pytest.raises(ValueError):
        position_weights(sig, 0.1, scheme="softmax")
    with pytest.raises(ValueError):
        position_weights(sig, 0.1, scheme="inverse_vol")  # needs scale


def test_inverse_vol_and_market_cap_sizing() -> None:
    prices, sig = _signal()
    vol = trailing_volatility(prices, 63)
    w = position_weights(sig, 0.2, long_only=True, scheme="inverse_vol", scale=vol)
    live = w.sum(axis=1) > 0
    assert np.allclose(w[live].sum(axis=1), 1.0) and (w >= 0).all().all()
    last = w.iloc[-1]
    held = last[last > 0].index
    assert np.corrcoef(last[held], vol.iloc[-1][held])[0, 1] < 0
    cap = pd.DataFrame(np.tile(np.arange(1, 61, dtype=float), (len(prices), 1)), index=prices.index, columns=prices.columns)
    wc = position_weights(sig, 0.2, long_only=True, scheme="market_cap", scale=cap).iloc[-1]
    held = wc[wc > 0].index
    assert np.corrcoef(wc[held], cap.iloc[-1][held])[0, 1] > 0.99


def test_max_weight_cap_and_infeasible_warning(caplog) -> None:
    prices, sig = _signal()
    w = position_weights(sig, 0.1, scheme="score", max_weight=0.3)
    assert w.abs().max().max() <= 0.3 + 1e-9
    with caplog.at_level("WARNING"):
        short_leg = position_weights(sig, 0.1, long_only=True, scheme="equal", max_weight=0.05)  # 6 names cannot carry 100 %
    assert "infeasible" in caplog.text
    assert short_leg.sum(axis=1).max() <= 0.3 + 1e-9


def test_buffer_reduces_turnover_and_degenerates_to_plain() -> None:
    prices, sig = _signal()
    reb = rebalance_dates(prices.index, "M")
    plain = quantile_weights(sample_on(sig, reb), 0.1)
    buffered = buffered_weights(sig, 0.1, 0.2, dates=reb)
    live = buffered.abs().sum(axis=1) > 0
    assert np.allclose(buffered[live].clip(lower=0).sum(axis=1), 1.0) and np.allclose(buffered[live].clip(upper=0).sum(axis=1), -1.0)
    assert turnover(buffered).sum() < 0.75 * turnover(plain).sum()
    same = buffered_weights(sig, 0.1, 0.1, dates=reb)
    np.testing.assert_allclose(same.to_numpy(), plain.to_numpy())
    lo = buffered_weights(sig, 0.2, 0.3, long_only=True, dates=reb)
    assert (lo >= 0).all().all() and np.allclose(lo[lo.sum(axis=1) > 0].sum(axis=1), 1.0)
    with pytest.raises(ValueError):
        buffered_weights(sig, 0.2, 0.1)


def test_tilt_weights_behave_like_an_enhanced_index() -> None:
    prices, sig = _signal()
    rng = np.random.default_rng(1)
    bw = rng.lognormal(size=60)
    bw /= bw.sum()
    bench = pd.DataFrame([bw] * len(prices), index=prices.index, columns=prices.columns)
    live = sig.notna().any(axis=1)
    np.testing.assert_allclose(tilt_weights(bench, sig, strength=0.0).to_numpy(), bench.to_numpy())
    t = tilt_weights(bench, sig, strength=1.0)
    assert np.allclose(t[live].sum(axis=1), 1.0) and (t >= 0).all().all()
    a = active_weights(t, bench).iloc[-1]
    assert a[sig.iloc[-1].idxmax()] > 0 and a[sig.iloc[-1].idxmin()] < 0
    capped = tilt_weights(bench, sig, strength=2.0, max_active=0.01)
    assert active_weights(capped, bench)[live].abs().max().max() <= 0.01 + 1e-6
    assert np.allclose(capped[live].sum(axis=1), 1.0)
    # names without a score are held at benchmark weight, not sold
    holed = sig.copy()
    holed.iloc[:, 0] = np.nan
    th = tilt_weights(bench, holed, strength=1.0)
    assert (th.iloc[-1, 0] > 0) and abs(active_weights(th, bench).iloc[-1, 0]) < 0.05


def test_clip_active_weights_projection() -> None:
    b = pd.DataFrame([[0.5, 0.3, 0.2]], columns=[1, 2, 3])
    w = pd.DataFrame([[0.8, 0.1, 0.1]], columns=[1, 2, 3])
    out = clip_active_weights(w, b, 0.1)
    assert np.isclose(out.sum(axis=1).iloc[0], 1.0)
    assert ((out - b).abs() <= 0.1 + 1e-9).all().all()


def test_sector_caps_and_sector_weights() -> None:
    prices, sig = _signal()
    sectors = pd.Series(["A"] * 30 + ["B"] * 20 + ["C"] * 10, index=prices.columns)
    lo = long_only_weights(sig, 0.5)
    live = lo.sum(axis=1) > 0
    assert sector_weights(lo, sectors)[live].max().max() > 0.4
    capped = cap_sector_weights(lo, sectors, 0.4)
    assert sector_weights(capped, sectors)[live].max().max() <= 0.4 + 1e-6
    assert np.allclose(capped[live].sum(axis=1), 1.0)
    jointly = cap_sector_weights(lo, sectors, 0.45, max_weight=0.08)
    assert jointly.max().max() <= 0.08 + 1e-9
    with pytest.raises(ValueError):
        cap_sector_weights(lo, sectors, 1.5)


def test_membership_matrix_forward_fills_snapshots() -> None:
    members_on = pd.Series({pd.Timestamp("2021-01-04"): {1, 2}, pd.Timestamp("2021-01-06"): {2, 3}})
    dates = pd.bdate_range("2021-01-01", periods=6)
    m = membership_matrix(members_on, dates, [1, 2, 3, 4])
    assert m.dtypes.eq(bool).all() and m.shape == (6, 4)
    assert not m.loc["2021-01-01"].any()  # before the first snapshot
    assert m.loc["2021-01-05", 1] and not m.loc["2021-01-05", 3]  # carries the 4 Jan snapshot
    assert m.loc["2021-01-08", 3] and not m.loc["2021-01-08", 1]
    assert not m[4].any()
    assert membership_matrix(None, dates, [1, 2]).all().all()


def test_summary_table_active_stats() -> None:
    rng = np.random.default_rng(0)
    idx = pd.bdate_range("2023-01-01", periods=400)
    rets = pd.DataFrame({"bench": rng.normal(0.0004, 0.01, 400)}, index=idx)
    rets["book"] = rets["bench"] + 0.0002 + rng.normal(0, 0.003, 400)
    table = summary_table(rets, benchmark="bench")
    assert {"active_return", "information_ratio"} <= set(table.columns)
    assert table.loc["book", "active_return"] > 0 and table.loc["book", "information_ratio"] > 0
    assert np.isnan(table.loc["bench", "information_ratio"])


def test_strategy_config_end_to_end_and_round_trip() -> None:
    prices = synthetic_prices(n_securities=50, n_days=600, seed=4)
    quarter_ends = pd.date_range(prices.index[0] - pd.offsets.QuarterEnd(2), prices.index[-1], freq="QE")
    history = synthetic_fundamentals_history(list(prices.columns), quarter_ends, seed=3)
    rng = np.random.default_rng(0)
    for col in ("Revenue Growth", "Earnings Growth", "EBIT Growth", "Gross Margin Change"):
        history[col] = rng.normal(0.08, 0.15, len(history))
    provider = InMemoryFundamentalsProvider(history, availability_lag_days=45, metric_columns=METRIC_COLUMNS)
    cfg = StrategyConfig(
        "TEST_LO",
        [
            SignalSpec("momentum", "momentum", 0.4, {"lookback": 126, "skip": 21}),
            SignalSpec("value", "value", 0.3),
            SignalSpec("growth", "growth", 0.3),
            SignalSpec("custom", "ratio_composite", 0.2, {"specs": [RatioSpec("RoE").to_dict(), RatioSpec("Debt/Equity", direction=-1).to_dict()], "name": "custom"}),
        ],
        quantile=0.2,
        exit_quantile=0.3,
        long_only=True,
        position_weighting="score",
        max_weight=0.15,
        min_names=10,
    )
    reb = rebalance_dates(prices.index, "M")
    signals = compute_signals(cfg, prices, reb, provider=provider)
    assert set(signals) == {"momentum", "value", "growth", "custom"} and all(s.shape == prices.shape for s in signals.values())
    composite = blend(cfg, signals, reb)
    weights = build_weights(cfg, composite, rebalances=reb)
    live = weights.sum(axis=1) > 0
    assert np.allclose(weights[live].sum(axis=1), 1.0) and (weights >= 0).all().all() and weights.max().max() <= 0.15 + 1e-9
    result = run_backtest(weights, prices_to_returns(prices), shift_weights=1, cost_bps=cfg.cost_bps)
    assert len(result.returns) == len(prices)
    assert cfg.needs_growth_metrics()
    with pytest.raises(ValueError):
        compute_signals(cfg, prices, reb, provider=InMemoryFundamentalsProvider(history, availability_lag_days=45))  # no growth metrics served
    # persistence
    data = json.loads(json.dumps(cfg.to_dict(), default=str))
    again = StrategyConfig.from_dict(data)
    assert again.to_dict() == cfg.to_dict()
    path = os.path.join(tempfile.mkdtemp(), "cfg.json")
    cfg.save(path)
    assert StrategyConfig.load(path).weights() == cfg.weights()
    assert cfg.with_updates(quantile=0.25).quantile == 0.25 and cfg.quantile == 0.2
    assert MOMENTUM_ML_VALUE_LONG_ONLY.long_only and MOMENTUM_ML_VALUE_LONG_ONLY.needs_growth_metrics()
    with pytest.raises(ValueError):
        StrategyConfig("bad", [SignalSpec("a", "momentum"), SignalSpec("a", "value")])
    with pytest.raises(ValueError):
        StrategyConfig("bad", [SignalSpec("a", "momentum")], position_weighting="nope")
