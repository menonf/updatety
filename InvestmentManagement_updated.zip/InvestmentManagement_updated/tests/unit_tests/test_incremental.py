"""Incremental loaders: window maths, membership diff, fundamentals diff, gap report (no database, no vendor)."""

import numpy as np
import pandas as pd

from analytics.factors.ml_training import retrain_recommended, save_training_metadata
from data_engineering.loaders.incremental import (
    FundamentalsDiff,
    MembershipDiff,
    diff_fundamentals,
    diff_membership,
    fundamentals_window,
    price_gaps_from_frames,
    price_window,
)


def test_price_window_buffers_and_falls_back() -> None:
    assert price_window("2026-10-14", as_of="2026-10-17", buffer_days=3) == ("2026-10-09", "2026-10-17")
    assert price_window(None, as_of="2026-10-17", fallback_days=30) == ("2026-09-17", "2026-10-17")
    start, end = price_window("2026-10-17", as_of="2026-10-17", buffer_days=0)  # already caught up -> still a one-day window
    assert start < end
    assert fundamentals_window("2026-10-17", 2) == ("2026-04-17", "2026-10-17")


def test_diff_membership_identifies_joiners_leavers_and_event_dates() -> None:
    stored = pd.DataFrame({"security_id": [1, 2, 3, 4], "exchange_ticker": ["AAA", "BBB", "CCC", "DDD"], "start_date": ["2020-01-01"] * 4})
    current = pd.DataFrame(
        {"ric": ["AAA.O", "BBB.N", "DDD.O", "EEE.O", "FFF.N"], "exchange_ticker": ["AAA", "BBB", "DDD", "EEE", "FFF"], "security_id": [1, 2, 4, 5, np.nan]}
    )
    events = pd.DataFrame({"ric": ["EEE.OQ", "CCC.N"], "exchange_ticker": ["EEE", "CCC"], "date": ["2026-09-22", "2026-09-22"], "change": ["Joiner", "Leaver"]})
    diff = diff_membership(stored, current, events, as_of="2026-10-17")
    assert isinstance(diff, MembershipDiff) and not diff.is_empty
    assert diff.summary() == {"as_of": pd.Timestamp("2026-10-17").date(), "joiners": 2, "leavers": 1, "unchanged": 3, "unresolved_joiners": 1}
    joiners = diff.joiners.set_index("ric")
    assert joiners.loc["EEE.O", "date"] == pd.Timestamp("2026-09-22")  # matched on the normalised RIC despite .OQ vs .O
    assert joiners.loc["FFF.N", "date"] == pd.Timestamp("2026-10-17") and np.isnan(joiners.loc["FFF.N", "security_id"])
    assert diff.leavers["security_id"].tolist() == [3] and diff.leavers["date"].iloc[0] == pd.Timestamp("2026-09-22")
    log = diff.change_log()
    assert list(log["change"]) == ["JOINER", "JOINER", "LEAVER"] and (log["as_of"] == pd.Timestamp("2026-10-17")).all()
    same = diff_membership(stored, pd.DataFrame({"ric": list("ABCD"), "exchange_ticker": list("ABCD"), "security_id": [1, 2, 3, 4]}), None, "2026-10-17")
    assert same.is_empty and same.unchanged == 4


def test_diff_fundamentals_classifies_cells_periods_and_coverage() -> None:
    stored = pd.DataFrame(
        {"security_id": [1, 1, 2], "metric_type": ["P/E", "P/B", "P/E"], "metric_value": [10.0, 2.0, 15.0], "effective_date": ["2026-03-31"] * 3, "source_vendor": "refinitiv"}
    )
    incoming = pd.DataFrame(
        {
            "security_id": [1, 1, 1, 2, 3],
            "metric_type": ["P/E", "P/B", "P/E", "P/E", "P/E"],
            "metric_value": [10.0 + 1e-9, 2.5, 11.0, 15.0, 9.0],
            "effective_date": ["2026-03-31", "2026-03-31", "2026-06-30", "2026-03-31", "2026-06-30"],
            "source_vendor": "refinitiv",
            "end_date": None,
        }
    )
    diff = diff_fundamentals(stored, incoming, universe_ids=[1, 2, 3, 4], stored_any=[1, 2])
    assert isinstance(diff, FundamentalsDiff)
    assert diff.summary() == {
        "new_cells": 2,
        "restated_cells": 1,
        "unchanged_cells": 2,
        "new_periods": 2,
        "securities_with_new_period": 2,
        "newly_covered_securities": 1,
        "securities_without_vendor_rows": 1,
    }
    assert diff.restated_rows.loc[0, ["metric_type", "previous_value", "metric_value"]].tolist() == ["P/B", 2.0, 2.5]
    assert diff.new_periods["security_id"].tolist() == [1, 3] and diff.newly_covered == [3] and diff.no_incoming == [4]
    assert len(diff.rows_to_write) == 3
    empty = diff_fundamentals(stored, incoming.iloc[0:0], universe_ids=[1, 2])
    assert empty.rows_to_write.empty and empty.no_incoming == [1, 2]


def test_price_gaps_infer_the_trading_calendar() -> None:
    dates = pd.bdate_range("2026-10-05", "2026-10-16")
    holiday = pd.Timestamp("2026-10-12")
    rows = [(s, d) for s in (1, 2, 3, 4) for d in dates if d != holiday]
    rows = [r for r in rows if not (r[0] == 3 and r[1] in (pd.Timestamp("2026-10-14"), pd.Timestamp("2026-10-15")))]
    rows = [r for r in rows if r[0] != 4]
    priced = pd.DataFrame(rows, columns=["security_id", "as_of_date"])
    gaps = price_gaps_from_frames(priced, [1, 2, 3, 4])
    assert gaps["security_id"].tolist() == [4, 3]  # worst first
    assert (gaps["expected_days"] == 9).all()  # the holiday is not a trading day
    assert gaps.set_index("security_id").loc[3, "missing_dates"] == "2026-10-14, 2026-10-15"
    assert price_gaps_from_frames(priced.iloc[0:0], [1]).empty


def test_retrain_recommended_logic(tmp_path) -> None:
    model_dir = str(tmp_path)
    for key in ("random_forest", "extra_trees", "gradient_boosting"):
        (tmp_path / f"{key}.joblib").write_bytes(b"x")
    save_training_metadata(model_dir, {"as_of": "2026-08-31", "availability_lag_days": 45, "models": ["random_forest", "extra_trees", "gradient_boosting"]})
    assert not retrain_recommended(model_dir, "2026-06-30", as_of="2026-10-17")["recommended"]  # already covered
    assert not retrain_recommended(model_dir, "2026-09-30", as_of="2026-10-17")["recommended"]  # not yet published (lag)
    assert retrain_recommended(model_dir, "2026-09-30", as_of="2026-11-20")["recommended"]  # published after the cut-off
    assert retrain_recommended(str(tmp_path / "missing"), "2026-09-30")["recommended"]  # no models at all
    assert not retrain_recommended(model_dir, None)["recommended"]
