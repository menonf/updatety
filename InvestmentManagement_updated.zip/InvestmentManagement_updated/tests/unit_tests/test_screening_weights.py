"""Screen position weighting, long-only screens, sizing to capital and the order list (pure pandas)."""

import numpy as np
import pandas as pd
import pytest

from analytics.screening import build_screen, enrich_screen, screen_changes, size_positions, summarize_screen, trade_list, watchlist


def _components(n: int = 60, seed: int = 0):
    idx = pd.bdate_range("2024-01-01", periods=2)
    cols = list(range(1, n + 1))
    rng = np.random.default_rng(seed)
    mom = pd.DataFrame(rng.normal(size=(2, n)), index=idx, columns=cols)
    val = pd.DataFrame(rng.normal(size=(2, n)), index=idx, columns=cols)
    return idx, cols, {"momentum": mom, "value": val}, rng


def test_position_weighting_changes_sizes_not_selection() -> None:
    idx, cols, comps, _ = _components()
    equal = build_screen(comps, idx[1], quantile=0.1)
    score = build_screen(comps, idx[1], quantile=0.1, position_weighting="score")
    assert set(equal.index[equal["side"] != ""]) == set(score.index[score["side"] != ""])
    for s in (equal, score):
        assert np.isclose(s.loc[s["weight"] > 0, "weight"].sum(), 1.0) and np.isclose(s.loc[s["weight"] < 0, "weight"].sum(), -1.0)
    assert equal.loc[equal["weight"] != 0, "weight"].round(9).nunique() == 2
    assert score.loc[score["weight"] != 0, "weight"].round(9).nunique() > 2
    longs = score[score["side"] == "LONG"]
    assert (longs.sort_values("weight")["composite"].diff().dropna() >= 0).all()
    assert score.attrs["position_weighting"] == "score" and score.attrs["long_only"] is False
    with pytest.raises(ValueError):
        build_screen(comps, idx[1], position_weighting="magic")


def test_long_only_screen_with_cap_rank_and_inverse_vol() -> None:
    idx, cols, comps, rng = _components()
    lo = build_screen(comps, idx[1], quantile=0.2, long_only=True, position_weighting="rank", max_weight=0.12)
    assert (lo["weight"] >= 0).all() and np.isclose(lo["weight"].sum(), 1.0) and lo["weight"].max() <= 0.12 + 1e-9
    assert (lo["side"] == "SHORT").sum() == 0 and (lo["side"] == "LONG").sum() == 12
    vol = pd.Series(rng.uniform(0.15, 0.6, len(cols)), index=cols)
    iv = build_screen(comps, idx[1], quantile=0.2, long_only=True, position_weighting="inverse_vol", weight_inputs=vol)
    held = iv.index[iv["weight"] > 0]
    assert np.corrcoef(iv.loc[held, "weight"], vol[held])[0, 1] < 0
    watch = watchlist(lo, band=0.05)
    assert (watch["watch"] == "NEAR LONG").all()
    summary = summarize_screen(lo)
    assert summary["n_short"] == 0 and np.isclose(summary["net_exposure"], 1.0)


def test_size_positions_rounds_down_to_lots() -> None:
    idx, cols, comps, rng = _components()
    screen = build_screen(comps, idx[1], quantile=0.1, position_weighting="score")
    px = pd.Series(rng.uniform(20, 500, len(cols)), index=cols)
    sized = size_positions(enrich_screen(screen, idx[1], prices=px), capital=1_000_000, lot_size=10)
    assert {"target_value", "target_shares", "actual_weight"} <= set(sized.columns)
    selected = sized[sized["side"] != ""]
    assert (selected["target_shares"] % 10 == 0).all()
    assert (selected["actual_weight"].abs() <= selected["weight"].abs() + 1e-12).all()
    assert np.allclose(selected["target_value"], selected["weight"] * 1_000_000)
    assert (np.sign(selected["target_shares"]) == np.sign(selected["weight"])).all()
    assert sized.attrs["capital"] == 1_000_000
    with pytest.raises(ValueError):
        size_positions(screen, capital=0)


def test_trade_list_covers_entries_exits_flips_and_resizes() -> None:
    idx, cols, comps, rng = _components()
    px = pd.Series(rng.uniform(20, 500, len(cols)), index=cols)
    current = enrich_screen(build_screen(comps, idx[1], quantile=0.1, position_weighting="score"), idx[1], prices=px)
    previous = enrich_screen(build_screen(comps, idx[0], quantile=0.1, position_weighting="score"), idx[0], prices=px)
    orders = trade_list(current, previous, capital=1_000_000)
    assert {"previous_weight", "current_weight", "delta_weight", "action", "trade_value", "trade_shares"} <= set(orders.columns)
    assert np.allclose(orders["delta_weight"], orders["current_weight"] - orders["previous_weight"])
    assert (orders["delta_weight"].abs().diff().dropna() <= 1e-12).all()  # sorted by size
    # every name whose side changed appears in the order list too
    changed = screen_changes(current, previous)
    assert set(changed.index) <= set(orders.index)
    assert "previous_weight" in changed.columns
    # a pure resize (same side, different weight) is an order but not a side change
    resized = orders[(orders["previous_weight"] > 0) & (orders["current_weight"] > 0)]
    if len(resized):
        assert not set(resized.index) & set(changed.index)
        assert set(resized["action"]) <= {"BUY", "SELL"}
    flips = orders[orders["action"].str.startswith("FLIP")]
    assert ((np.sign(flips["previous_weight"]) * np.sign(flips["current_weight"])) < 0).all()
    unchanged = trade_list(current, current)
    assert unchanged.empty
