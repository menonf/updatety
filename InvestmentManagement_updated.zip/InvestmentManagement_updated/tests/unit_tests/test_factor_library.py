"""Declarative factor library: RatioSpec / RatioCompositeFactor, presets, growth metrics (pure pandas)."""

import numpy as np
import pandas as pd
import pytest

from analytics.factors import GrowthFactor, QualityFactor, RatioCompositeFactor, RatioSpec, ValueFactor, get_factor, registry
from analytics.factors.transforms import winsorize, zscore
from data_engineering.fundamentals import GROWTH_COLUMNS, METRIC_COLUMNS, RATIO_COLUMNS, compute_growth_ratios, compute_ratios_with_growth
from tests.unit_tests.synthetic import synthetic_fundamentals


def _legacy_value(panel, metrics=("EV/EBIT", "P/E", "P/B", "P/S"), winsor=(0.01, 0.99), min_components=1):
    """The original hand-written ValueFactor arithmetic, kept here as the reference."""
    comps = []
    for m in metrics:
        mult = panel[m].astype(float)
        yld = (1.0 / mult).where(mult > 0)
        if winsor is not None and yld.notna().sum() > 2:
            yld = winsorize(yld, *winsor)
        comps.append(zscore(yld))
    stacked = pd.DataFrame(comps).T
    score = stacked.mean(axis=1)
    return score.where(stacked.notna().sum(axis=1) >= min_components)


def test_value_factor_reproduces_legacy_numbers() -> None:
    panel = synthetic_fundamentals(list(range(1, 61)), seed=9)
    new = ValueFactor().score_panel(panel)
    old = _legacy_value(panel)
    pd.testing.assert_series_equal(new, old, check_names=False)
    sub = ValueFactor(metrics=["P/E", "P/B"], min_components=2).score_panel(panel)
    pd.testing.assert_series_equal(sub, _legacy_value(panel, ("P/E", "P/B"), min_components=2), check_names=False)


def test_adding_a_ratio_to_value_is_one_spec() -> None:
    panel = synthetic_fundamentals(list(range(1, 41)))
    base = ValueFactor()
    extended = ValueFactor(extra=[RatioSpec("Book Equity/TL")])
    assert extended.columns == base.columns + ["Book Equity/TL"]
    # the new component moves the score; a name with a very high Book Equity/TL gains
    panel.loc[1, "Book Equity/TL"] = panel["Book Equity/TL"].max() * 5
    assert extended.score_panel(panel).loc[1] > base.score_panel(panel).loc[1]
    dropped = ValueFactor(drop=["P/S"])
    assert "P/S" not in dropped.columns and len(dropped.columns) == 3


def test_spec_orientation_and_transforms() -> None:
    s = pd.Series([1.0, 2.0, 4.0, -1.0])
    assert RatioSpec("P/E", transform="inverse").oriented(s).tolist()[:3] == [1.0, 0.5, 0.25]
    assert np.isnan(RatioSpec("P/E", transform="inverse").oriented(s).iloc[3])  # non-positive -> missing
    assert RatioSpec("Debt/Equity", direction=-1).oriented(s).tolist() == [-1.0, -2.0, -4.0, 1.0]
    assert np.allclose(RatioSpec("P/S", transform="log").oriented(s).iloc[:3], np.log([1.0, 2.0, 4.0]))
    with pytest.raises(ValueError):
        RatioSpec("P/E", direction=2)
    with pytest.raises(ValueError):
        RatioSpec("P/E", transform="sqrt")


def test_composite_rejects_unknown_or_duplicate_metrics() -> None:
    with pytest.raises(ValueError):
        RatioCompositeFactor([RatioSpec("Not A Metric")])
    with pytest.raises(ValueError):
        RatioCompositeFactor([RatioSpec("P/E"), RatioSpec("P/E")])
    with pytest.raises(ValueError):
        RatioCompositeFactor([])


def test_composite_weights_and_min_components() -> None:
    panel = synthetic_fundamentals(list(range(1, 31)))
    heavy = RatioCompositeFactor([RatioSpec("RoE", weight=3.0), RatioSpec("ROCE", weight=1.0)], name="profit")
    comps = heavy.component_scores(panel)
    expected = (3.0 * comps["RoE"] + 1.0 * comps["ROCE"]) / 4.0
    pd.testing.assert_series_equal(heavy.score_panel(panel), expected, check_names=False)
    panel.loc[1, "ROCE"] = np.nan
    one_only = RatioCompositeFactor([RatioSpec("RoE"), RatioSpec("ROCE")], min_components=2).score_panel(panel)
    assert np.isnan(one_only.loc[1]) and one_only.drop(1).notna().all()
    assert heavy.name == "profit"
    rt = RatioCompositeFactor.from_dict(heavy.to_dict())
    assert rt.columns == heavy.columns and rt.specs[0].weight == 3.0


def test_growth_and_quality_presets_and_registry() -> None:
    assert {"growth", "quality", "ratio_composite", "ml_value"} <= set(registry)
    growth = GrowthFactor()
    assert growth.requires_growth_metrics() and set(growth.columns) <= set(GROWTH_COLUMNS)
    quality = get_factor("quality")
    assert isinstance(quality, QualityFactor) and "RoE" in quality.columns
    panel = synthetic_fundamentals(list(range(1, 41)))
    rng = np.random.default_rng(0)
    for col in GROWTH_COLUMNS:
        panel[col] = rng.normal(0.05, 0.1, len(panel))
    panel.loc[7, ["Revenue Growth", "Earnings Growth", "EBIT Growth", "Gross Margin Change"]] = [0.9, 0.9, 0.9, 0.3]
    score = growth.score_panel(panel)
    assert score.idxmax() == 7
    # asset growth and share issuance count AGAINST quality
    panel.loc[3, ["Asset Growth", "Share Issuance"]] = [2.0, 1.0]
    q_before = QualityFactor(drop=["Asset Growth", "Share Issuance"]).score_panel(panel).loc[3]
    assert QualityFactor().score_panel(panel).loc[3] < q_before


def test_compute_growth_ratios_ttm_and_missing_quarters() -> None:
    dates = pd.date_range("2021-03-31", periods=12, freq="QE")
    rev = pd.Series(100 * (1.10 ** (np.arange(12) / 4)), index=dates)
    items = pd.DataFrame(
        {"revenue": rev, "net_income": rev * 0.1, "ebit": rev * 0.15, "gross_profit": rev * 0.4, "total_assets": 1000 * (1.05 ** (np.arange(12) / 4)), "shares": 50.0},
        index=dates,
    )
    g = compute_growth_ratios(items)
    assert list(g.columns) == GROWTH_COLUMNS and g.index.equals(items.index)
    flows = ["Revenue Growth", "Earnings Growth", "EBIT Growth", "Gross Margin Change"]
    assert g[flows].iloc[:7].isna().all().all()  # TTM comparisons need 8 quarters
    assert g[["Asset Growth", "Share Issuance"]].iloc[:4].isna().all().all()  # point-to-point items need 4
    assert np.allclose(g["Revenue Growth"].iloc[7:], 0.10) and np.allclose(g["Earnings Growth"].iloc[7:], 0.10)
    assert np.allclose(g["Gross Margin Change"].iloc[7:], 0.0, atol=1e-12)
    assert np.allclose(g["Asset Growth"].iloc[4:], 0.05) and np.allclose(g["Share Issuance"].iloc[4:], 0.0)
    # a missing quarter poisons exactly the comparisons that need it, never misaligns them
    gapped = compute_growth_ratios(items.drop(dates[5]))
    assert np.isnan(gapped.loc[dates[8], "Revenue Growth"])  # TTM(2022Q1..Q4) needs 2022Q2
    assert np.isclose(gapped.loc[dates[4], "Asset Growth"], 0.05)
    # negative earnings never produce a growth number
    losses = pd.DataFrame({"net_income": -np.ones(16)}, index=pd.date_range("2020-03-31", periods=16, freq="QE"))
    assert compute_growth_ratios(losses)["Earnings Growth"].isna().all()
    # off-cycle fiscal calendar, unsorted input and a duplicated date
    d2 = pd.to_datetime(["2022-01-31", "2021-10-31", "2022-04-30", "2022-07-31", "2022-10-31", "2023-01-31", "2023-04-30", "2023-07-31", "2023-10-31", "2023-10-31"])
    odd = compute_growth_ratios(pd.DataFrame({"revenue": [100, 95, 105, 110, 115, 120, 125, 130, 135, 135.0]}, index=d2))
    assert np.isclose(odd.loc[pd.Timestamp("2023-07-31"), "Revenue Growth"], (115 + 120 + 125 + 130) / (95 + 100 + 105 + 110) - 1)
    assert len(odd) == 10
    full = compute_ratios_with_growth(items)
    assert list(full.columns) == METRIC_COLUMNS and full.shape[0] == 12


def test_metric_contract_is_additive() -> None:
    assert METRIC_COLUMNS[: len(RATIO_COLUMNS)] == RATIO_COLUMNS
    assert len(set(METRIC_COLUMNS)) == len(METRIC_COLUMNS)
